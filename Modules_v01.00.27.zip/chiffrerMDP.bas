Attribute VB_Name = "chiffrerMDP"
''Option Explicit
''
''Sub ChiffrerAES_16Caracteres_Phrase()
''    Dim TEMP_PATH As String
''    Dim mdpOriginal As String
''    Dim mdpNettoye As String
''    Dim phrasePasse As String
''    Dim texteChiffre As String
''
''    TEMP_PATH = Environ("TEMP") & "\Security\"
''
''    mdpOriginal = InputBox("Mot de passe Google App (16 caracteres apres nettoyage espaces)")
''    If mdpOriginal = "" Then Exit Sub
''
''    mdpNettoye = Trim(Replace(mdpOriginal, " ", ""))
''    If Len(mdpNettoye) <> 16 Then
''        MsgBox "ERREUR: 16 caracteres EXACTS requis apres nettoyage!", vbCritical
''        Exit Sub
''    End If
''
''    phrasePasse = InputBox("Entrez votre phrase de passe (8+ caracteres) pour le chiffrement AES :")
''    If Len(phrasePasse) < 8 Then
''        MsgBox "Phrase de passe trop courte!", vbCritical
''        Exit Sub
''    End If
''
''    texteChiffre = ChiffrerAES_PowerShell(mdpNettoye, phrasePasse)
''
''    If Left(texteChiffre, 6) = "ERREUR" Then
''        MsgBox texteChiffre, vbCritical
''        Exit Sub
''    End If
''
''    Call CreateFolder(TEMP_PATH)
''    Call SauverFichierChiffre(TEMP_PATH & "mdp_aes_phrase.enc", texteChiffre)
''
''    MsgBox "Fichier chiffr� : " & TEMP_PATH & "mdp_aes_phrase.enc", vbInformation
''End Sub
''
''
''Private Function ChiffrerAES_PowerShell(texte As String, phrasePasse As String) As String
''    Dim shell As Object
''    Dim exec As Object
''    Dim cmd As String
''    Dim result As String
''
''    On Error GoTo ErrPS
''
''    ' PowerShell : PBKDF2 + AES chiffrement en 1 commande
''    cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command " & _
''          """$secure = '" & texte & "' | ConvertTo-SecureString -AsPlainText -Force;" & _
''          "$bytes = [System.Text.Encoding]::UTF8.GetBytes($secure);" & _
''          "$key = [System.Security.Cryptography.Rfc2898DeriveBytes]::new('" & phrasePasse & "',[Text.Encoding]::UTF8.GetBytes('SelFixe1234'),10000).GetBytes(32);" & _
''          "$aes = [System.Security.Cryptography.Aes]::Create();" & _
''          "$aes.Key = $key; $aes.IV = [byte[]](0..15);" & _
''          "$enc = $aes.CreateEncryptor();" & _
''          "$result = $enc.TransformFinalBlock($bytes,0,$bytes.Length);" & _
''          "[Convert]::ToBase64String($result)"""
''
''    Set shell = CreateObject("WScript.Shell")
''    Set exec = shell.exec(cmd)
''    result = exec.StdOut.ReadAll
''    result = Replace(Replace(result, vbCrLf, ""), " ", "")
''
''    ChiffrerAES_PowerShell = result
''    Exit Function
''
''ErrPS:
''    ChiffrerAES_PowerShell = "ERREUR PowerShell: " & Err.Description
''End Function
''
''
''Private Sub SauverFichierChiffre(fichier As String, donnees As String)
''    Dim fileNum As Integer
''    fileNum = FreeFile()
''    Open fichier For Binary Access Write As #fileNum
''    Put #fileNum, , donnees
''    Close #fileNum
''End Sub
''
''Private Sub CreateFolder(path As String)
''    Dim fso As Object
''    Set fso = CreateObject("Scripting.FileSystemObject")
''    If Not fso.FolderExists(path) Then fso.CreateFolder path
''End Sub
'
'
'Sub ChiffrerMDP_Final()
'    Dim mdp As String: mdp = "MonMDP1234567890"
'    Dim phrase As String: phrase = "MaPhraseSecrete2026"
'    Dim psFile As String: psFile = Environ("TEMP") & "\aes_encrypt.ps1"
'
'    Dim f As Integer: f = FreeFile
'    Open psFile For Output As #f
'    Print #f, "$plainText = [Text.Encoding]::UTF8.GetBytes(""" & mdp & """)"
'    Print #f, "$key = [Text.Encoding]::UTF8.GetBytes(""" & phrase & """) | Select-Object -First 32"
'    Print #f, "$iv = $key[0..15]"
'    Print #f, "$aes = New-Object System.Security.Cryptography.AesManaged"
'    Print #f, "$aes.Key = $key"
'    Print #f, "$aes.IV = $iv"
'    Print #f, "$aes.Mode = [System.Security.Cryptography.CipherMode]::CBC"
'    Print #f, "$aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7"
'    Print #f, "$encryptor = $aes.CreateEncryptor()"
'    Print #f, "$cipherText = $encryptor.TransformFinalBlock($plainText, 0, $plainText.Length)"
'    Print #f, "$fullData = $iv + $cipherText"
'    Print #f, "[Convert]::ToBase64String($fullData)"
'    Close #f
'
'    Dim shell As Object: Set shell = CreateObject("WScript.Shell")
'    Dim exec As Object: Set exec = shell.exec("powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & psFile & """")
'    Do While exec.Status = 0: DoEvents: Loop
'
'    Dim result As String: result = Trim(exec.StdOut.ReadAll)
'    Debug.Print "FICHIER: " & result
'    Debug.Print "PHRASE: " & phrase
'
'    Open TEMP_PATH & "mdp_aes_phrase.enc" For Output As #1
'    Print #1, result
'    Close #1
'    Kill psFile
'
'    ' TEST D�CHIFFREMENT
'    Dim decryptResult As String: decryptResult = DechiffrerAES_Final(result, phrase)
'    Debug.Print "D�CHIFFR�: [" & decryptResult & "]"
'    MsgBox "R�sultat: " & decryptResult
'End Sub
'
'
'
'Private Function DechiffrerAES_Final(texteChiffre As Variant, phrasePasse As Variant) As String
'    Dim psFile As String: psFile = Environ("TEMP") & "\aes_decrypt.ps1"
'
'    ' CR�ER FICHIER POWERSHELL PROPRE
'    Dim f As Integer: f = FreeFile
'    Open psFile For Output As #f
'    Print #f, "$cipherText = [Convert]::FromBase64String(""" & texteChiffre & """)"
'    Print #f, "$key = [Text.Encoding]::UTF8.GetBytes(""" & phrasePasse & """) | Select-Object -First 32"
'    Print #f, "$iv = $cipherText[0..15]"
'    Print #f, "$encryptedData = $cipherText[16..($cipherText.Length-1)]"
'    Print #f, "$aes = New-Object System.Security.Cryptography.AesManaged"
'    Print #f, "$aes.Key = $key"
'    Print #f, "$aes.IV = $iv"
'    Print #f, "$aes.Mode = [System.Security.Cryptography.CipherMode]::CBC"
'    Print #f, "$aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7"
'    Print #f, "$decryptor = $aes.CreateDecryptor()"
'    Print #f, "$decrypted = $decryptor.TransformFinalBlock($encryptedData, 0, $encryptedData.Length)"
'    Print #f, "[Text.Encoding]::UTF8.GetString($decrypted)"
'    Close #f
'
'    ' EX�CUTER
'    Dim shell As Object: Set shell = CreateObject("WScript.Shell")
'    Dim exec As Object: Set exec = shell.exec("powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & psFile & """ 2>&1")
'
'    Do While exec.Status = 0: DoEvents: Loop
'
'    ' NETTOYER
'    On Error Resume Next
'    Kill psFile
'    On Error GoTo 0
'
'    DechiffrerAES_Final = Trim(exec.StdOut.ReadAll)
'End Function
'
'
'Sub TestComplet()  ' ? PARFAIT
'    ChiffrerMDP_Final      ' ? Cr�e nouveau bloc IV(16)+DATA(16)
'    ' Lecture BINAIRE + Trim = ROBUSTE ?
'    Open TEMP_PATH & "mdp_aes_phrase.enc" For Binary As #f
'    contenu = Space$(LOF(f))  ' ? Lecture binaire pure
'    Get #f, , contenu
'    ligneEnc = Trim(contenu)  ' ? Nettoie espaces
'
'    mdpGoogle = DechiffrerAES_Final(ligneEnc, phrase32)  ' ? Nouveau format
'    MsgBox mdpGoogle  ' ? "MonMDP1234567890"
'End Sub
'
'
