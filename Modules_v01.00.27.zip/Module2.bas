Attribute VB_Name = "Module2"
Sub dfg()
MsgBox ThisWorkbook.CustomDocumentProperties("Version").Value
End Sub
