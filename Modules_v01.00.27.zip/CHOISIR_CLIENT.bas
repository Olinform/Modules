Attribute VB_Name = "CHOISIR_CLIENT"
Public chemin As String
Public fichierFactDevis
Public CaptionChoisieTYPEClient As String
Public CaptionChoisieCLIENT As String
Public CaptionChoisieCopieColleMODULS As String

Function ChoisirDossierTravailTableau(nom_client, lign) As String
    Dim nomDossier As String
    Dim ligne As Long
    Dim choix As String
    Dim i As Long
    Dim msg As String
    
    Dim wb As Workbook, ws As Worksheet
    Set wb = ThisWorkbook
    Set ws = wb.Sheets(1)
    
    Dim wsFactDev As Worksheet
    Dim wbFactDev As Workbook
    
    For i = 1 To Application.Workbooks.Count
        If InStr(Application.Workbooks(i).Name, "FACTURES DEVIS") <> 0 Then Set wbFactDev = Application.Workbooks(i): nomFichierFactDev = wbFactDev.Name
        Set wsFactDev = wbFactDev.Worksheets("Factures")
    Next i
    
    
    colNumFact = Chr(64 + wsFactDev.Range("NUMFACTURE").Column) ' A
    colClient = Chr(64 + wsFactDev.Range("CLIENT").Column) ' B
    colObjet = Chr(64 + wsFactDev.Range("OBJET").Column) ' C
    colDateFact = Chr(64 + wsFactDev.Range("DateEmmissionFacture").Column) ' D
    coltotalHT = Chr(64 + wsFactDev.Range("TOTALHT").Column)  ' E
    colTotalTTC = Chr(64 + wsFactDev.Range("TOTALTTC").Column)  ' F
    colPaiement = Chr(64 + wsFactDev.Range("paiementrecule").Column) ' G
    colPaiementPar = Chr(64 + wsFactDev.Range("PaiementPar").Column)
    colMainDoeuvre = Chr(64 + wsFactDev.Range("MainDoeuvre").Column)
    colTVA = Chr(64 + wsFactDev.Range("TVA").Column)
    colURSSAF = Chr(64 + wsFactDev.Range("URSSAF").Column)
    colAutreFourniss = Chr(64 + wsFactDev.Range("AUTRESFOURNISSEURS").Column)
    colWELDOM = Chr(64 + wsFactDev.Range("WELDOM").Column)
    colBRICOLAGE = Chr(64 + wsFactDev.Range("BRICOLAGE").Column)
    coltotalFournisseur = Chr(64 + wsFactDev.Range("TOTALFOURNISSEURS").Column)
    colNetAttente = Chr(64 + wsFactDev.Range("netenattente").Column)
    colNetGagne = Chr(64 + wsFactDev.Range("netdejagagne").Column)

    
    ' TABLEAUX pour stocker les types de clients
    Dim listeDossiers() As String
    Dim nbDossiers As Long
    
choixClient:
    
    ' CHEMIN DYNAMIQUE
    If nom_client = "" Then
        chemin = recupCheminnNomEntreprise
        chemin = chemin & Dir(chemin & "*FACTURES-DEVIS", vbDirectory) & "\" & Year(Date) & "\"
    ElseIf nom_client = "AGENCES IMMO" Then
        chemin = recupCheminnNomEntreprise
        chemin = chemin & Dir(chemin & "*FACTURES-DEVIS", vbDirectory) & "\" & Year(Date) & "\" & "0 - AGENCES IMMO" & "\"
    ElseIf nom_client = "SOUS-TRAITANCE" Then
        chemin = recupCheminnNomEntreprise
        chemin = chemin & Dir(chemin & "*FACTURES-DEVIS", vbDirectory) & "\" & Year(Date) & "\" & "1 - SOUS-TRAITANCE" & "\"
    ElseIf nom_client = "CLIENTS DIRECTS" Then
        chemin = recupCheminnNomEntreprise
        chemin = chemin & Dir(chemin & "*FACTURES-DEVIS", vbDirectory) & "\" & Year(Date) & "\" & "2 - CLIENTS DIRECTS" & "\"
    End If
'    MsgBox chemin
    If Dir(chemin, vbDirectory) = "" Then
        MsgBox "Dossier non trouv� : " & chemin, vbCritical
        Exit Function
    End If
    
    ' 1. LISTER LES DOSSIERS DANS UN TABLEAU
    ReDim listeDossiers(1 To 200)  ' Tableau dynamique (max 1000)
    nbDossiers = 0
    
    If nom_client = "" Then
        nomDossier = Dir(chemin, vbDirectory)
        Do While nomDossier <> ""
            If nomDossier <> "." And nomDossier <> ".." Then
                If (GetAttr(chemin & nomDossier) And vbDirectory) = vbDirectory Then
                    nbDossiers = nbDossiers + 1
                    listeDossiers(nbDossiers) = Split(nomDossier, " - ")(1)
                End If
            End If
            nomDossier = Dir()
        Loop
        
        If nbDossiers = 0 Then
            MsgBox "Aucun sous-dossier trouv� dans " & cheminTypeClient, vbExclamation
            Range("C1").Select
            Exit Function
        End If

        For i = 1 To nbDossiers
            Chx_TypeClient.ListBox1.AddItem i & " : " & listeDossiers(i)
        Next i
        
'    ' 3. DEMANDER LE CHOIX
        Chx_TypeClient.Show vbModal
        
        If CaptionChoisieTYPEClient = "" Then
            Call MOINS_UN.MOINS_UN
            Exit Function
        End If
        
choix:
        choix = Split(CaptionChoisieTYPEClient, " : ")(0)

        If choix <> "" Then

            Application.EnableEvents = False

            Select Case choix
                Case "1"
                    caseNumFactureOUDevis = Split(Range("A" & lign), "_")(1)
                    Numfact = CDbl(Right(caseNumFactureOUDevis, 3))
                    If Len(Numfact) = 2 Then
                        Range("A" & lign) = Left(Range("A" & lign), 8) & "0" & Numfact & "_DEP_PLB"
                        Range("A" & lign).Borders(xlEdgeTop).LineStyle = True
                        Range("A" & lign).Characters(Start:=10, Length:=2).Font.Color = vbRed
                    Else:
                        Range("A" & lign) = Left(Range("A" & lignderfact + 3), 8) & Numfact
                        Range("A" & lign).Borders(xlEdgeTop).LineStyle = True
                        Range("A" & lign).Characters(Start:=9, Length:=3).Font.Color = vbRed
                    End If

                    ChoisirDossierTravailTableau = Split(CaptionChoisieTYPEClient, " : ")(1)
                    
                    Application.EnableEvents = True

                Case "2"
                    caseNumFactureOUDevis = Split(Range("A" & lign), "_")(1)
                    Numfact = CDbl(Right(caseNumFactureOUDevis, 3))
                    If Len(Numfact) = 2 Then
                        Range("A" & lign) = Left(Range("A" & lign), 8) & "0" & Numfact & "_ST_PLB"
                        Range("A" & lign).Borders(xlEdgeTop).LineStyle = True
                        Range("A" & lign).Characters(Start:=10, Length:=2).Font.Color = vbRed
                    Else:
                        Range("A" & lign) = Left(Range("A" & lignderfact + 3), 8) & Numfact
                        Range("A" & lign).Borders(xlEdgeTop).LineStyle = True
                        Range("A" & lign).Characters(Start:=9, Length:=3).Font.Color = vbRed
                    End If

                    ChoisirDossierTravailTableau = Split(CaptionChoisieTYPEClient, " : ")(1)

                Case "3"
                    caseNumFactureOUDevis = Split(Range("A" & lign), "_")(1)
                    Numfact = CDbl(Right(caseNumFactureOUDevis, 3))
                    If Len(Numfact) = 2 Then
                        Range("A" & lign) = Left(Range("A" & lign), 8) & "0" & Numfact & "_CLI_PLB"
                        Range("A" & lign).Borders(xlEdgeTop).LineStyle = True
                        Range("A" & lign).Characters(Start:=10, Length:=2).Font.Color = vbRed
                    Else:
                        Range("A" & lign) = Left(Range("A" & lignderfact + 3), 8) & Numfact
                        Range("A" & lign).Borders(xlEdgeTop).LineStyle = True
                        Range("A" & lign).Characters(Start:=9, Length:=3).Font.Color = vbRed
                    End If

                    ChoisirDossierTravailTableau = Split(CaptionChoisieTYPEClient, " : ")(1)

                Case ""
                    Call MOINS_UN.MOINS_UN
                    Application.EnableEvents = True
                    End
            End Select

        ElseIf choix = "" Then
            Call MOINS_UN.MOINS_UN
            Application.EnableEvents = True
            End
        End If
        
    Else:
nouvodos:
        nbDossiers = 0
        nomDossier = Dir(chemin, vbDirectory)
        Do While nomDossier <> ""
            If nomDossier <> "." And nomDossier <> ".." Then
                If (GetAttr(chemin & nomDossier) And vbDirectory) = vbDirectory Then
                    nbDossiers = nbDossiers + 1
                    listeDossiers(nbDossiers) = nomDossier
                End If
            End If
            nomDossier = Dir()
        Loop
        
        If nbDossiers = 0 Then
            MsgBox "Aucun sous-dossier trouv� dans " & cheminTypeClient, vbExclamation
            Exit Function
        End If
        
        If nom_client = "SOUS-TRAITANCE" Then
'            Chx_Client.ListBox1.AddItem ""
            Chx_Client.ListBox1.AddItem "---- AJOUTER UN SOUS-TRAITANT ----"
            Chx_Client.ListBox1.AddItem ""
        ElseIf nom_client = "CLIENTS DIRECTS" Then
'            Chx_Client.ListBox1.AddItem ""
            Chx_Client.ListBox1.AddItem "------ AJOUTER UN CLIENT ------"
            Chx_Client.ListBox1.AddItem ""
        End If
        
        For i = 1 To nbDossiers
            Chx_Client.ListBox1.AddItem i & " : " & listeDossiers(i)
        Next i
        
        
'    ' DEMANDER LE CHOIX
        Chx_Client.Show vbModal
        
    ' 4. STOCKER DANS UN TABLEAU DE RESULTATS
        If CaptionChoisieCLIENT = "RETOUR EN ARRIERE" Then
            bouclageChoixTypeClient = 1
            nom_client = ""
            GoTo choixClient
        ElseIf CaptionChoisieCLIENT = "" Then
            Call MOINS_UN.MOINS_UN
            End
        End If
        
        If InStr(CaptionChoisieCLIENT, "AJOUTER") <> 0 Then
            nomNouveauDossier = InputBox(msg, "Donner un nom au nouveau dossier client :")
            If nomNouveauDossier = "" Then CaptionChoisieCLIENT = "": GoTo nouvodos
            Dim fso As Object
            Set fso = CreateObject("Scripting.FileSystemObject")
            If Not fso.FolderExists(chemin & nomNouveauDossier) Then
                MkDir (chemin & nomNouveauDossier)
                MkDir (chemin & nomNouveauDossier & "\FACTURES")
                MkDir (chemin & nomNouveauDossier & "\DEVIS")
            End If
            dossierChoisi = nomNouveauDossier
            ChoisirDossierTravailTableau = nomNouveauDossier
            
        ElseIf CaptionChoisieCLIENT <> "" Then
            valeurClientChoisi = Split(CaptionChoisieCLIENT, " : ")(0)
            If Val(valeurClientChoisi) >= 1 And Val(valeurClientChoisi) <= nbDossiers Then
                dossierChoisi = listeDossiers(Val(valeurClientChoisi))
            End If
            ChoisirDossierTravailTableau = Split(CaptionChoisieCLIENT, " : ")(1)
        ElseIf choix = "" Then
            Call MOINS_UN.MOINS_UN
            End
        End If
        
        GoTo Fin
    End If
    
    If nom_client = "" Then nom_client = Split(CaptionChoisieTYPEClient, " : ")(1): GoTo choixClient
    If nom_client <> "" Then nom_client = Split(ChoisirDossierTravailTableau, " - ")(1): GoTo choixClient

Fin:
    If ActiveSheet.Name = "Factures" Then
        Nouvelle_Facture.Hide
        Call CopierDernierDocxDir(nom_client, dossierChoisi, "FACTURES")
        Workbooks(fichierFactDevis).Sheets("Factures").Range("B" & lign) = dossierChoisi
    ElseIf ActiveSheet.Name = "Devis" Then
        Nouv_Devis.Hide
        Call CopierDernierDocxDir(nom_client, dossierChoisi, "DEVIS")
        Workbooks(fichierFactDevis).Sheets("Devis").Range("B" & lign) = dossierChoisi
    End If
        
End Function

Sub CopierDernierDocxDir(typeclient, client, FACTUREouDEVIS)
    Dim dossier As String, nomLocataire As String
    Dim fso As Object, cheminModele As String
    Dim fichier As String
    
    Application.EnableEvents = False
    
    fichierFactDevis = ActiveWorkbook.Name
' Rechercher *MODELE.xlsm dans le dossier
    If InStr(LCase(typeclient), "agences") <> 0 Then
        If FACTUREouDEVIS = "FACTURES" Then
            dossier = chemin & client & Dir("*AGENCES*") & "\FACTURES\"
            Debug.Print chemin
        ElseIf FACTUREouDEVIS = "DEVIS" Then
            dossier = chemin & client & Dir("*AGENCES*") & "\DEVIS\"
            Debug.Print dossier
        End If
        
'        MsgBox Dossier
    Else:
'    Dossier = chemin & client & "\" & FACTUREouDEVIS
        dossier = chemin
'        MsgBox fichier
    End If
    If FACTUREouDEVIS = "FACTURES" Then
        fichier = Dir(dossier & "\*FACT*MODELE*.xlsm")
    ElseIf FACTUREouDEVIS = "DEVIS" Then
        fichier = Dir(dossier & "\*DEV*MODELE*.xlsm")
    End If
    
    Do While fichier <> ""
        If InStr(UCase(fichier), "MODELE") > 0 Then Exit Do
        fichier = Dir
    Loop

    cheminModele = dossier & fichier  ' Chemin du mod�le
    
    If InStr(LCase(typeclient), "agence") <> 0 Then
        nomLocataire = UCase(InputBox("Nom locataire :"))
        Range("B" & Cells(Rows.Count, 1).End(xlUp).Row + 1) = nomLocataire
        If nomLocataire = "" Then
'            Shell "explorer.exe """ & Dossier & """", vbNormalFocus
            Call MOINS_UN.MOINS_UN
            Application.EnableEvents = True
            End
        End If
    ElseIf client = "" Then
'        Shell "explorer.exe """ & Dossier & """", vbNormalFocus
        Call MOINS_UN.MOINS_UN
        Application.EnableEvents = True
        End
    End If
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    
    ' V�rifier que le mod�le existe
    If Not fso.FileExists(cheminModele) Then
        MsgBox "MODELE introuvable dans " & cheminModele
        Call MOINS_UN.MOINS_UN
        Application.EnableEvents = True
        Exit Sub
    End If
    
    ' V�rifier que le dossier cible existe
    If Not fso.FolderExists(dossier) Then
        fso.CreateFolder dossier
    End If

    ' Copie avec nouveau nom
    Dim fichierCopie As String
    If FACTUREouDEVIS = "FACTURES" Then
        If InStr(typeclient, "IMMO") <> 0 Then
            nouveauNom = Format(Date, "yyyymmdd") & "-FACT-" & Split(client, " ")(0) & "-" & nomLocataire & ".xlsm"
        Else: nouveauNom = Format(Date, "yyyymmdd") & "-FACT-" & Split(client, " ")(0) & ".xlsm"
        End If
    ElseIf FACTUREouDEVIS = "DEVIS" Then
        If InStr(typeclient, "IMMO") <> 0 Then
            nouveauNom = Format(Date, "yyyymmdd") & "-DEV-" & Split(client, " ")(0) & "-" & nomLocataire & ".xlsm"
        Else: nouveauNom = Format(Date, "yyyymmdd") & "-DEV-" & Split(client, " ")(0) & ".xlsm"
        End If
    End If
    
    If InStr(LCase(typeclient), "agence") = 0 Then
        fichierCopie = dossier & client & "\" & FACTUREouDEVIS & "\" & nouveauNom
    Else: fichierCopie = dossier & nouveauNom
    End If
'    MsgBox fichierCopie
    ' Copie le fichier
    
onReouvre:
    On Error GoTo Erreur
    fso.CopyFile cheminModele, fichierCopie
    
    ' OUVERTURE + ATTENTE AUTOMATIQUE
    Dim wb As Workbook
    Set wb = Workbooks.Open(fichierCopie)
    wb.Activate

    If ActiveWorkbook.Name <> nouveauNom Then Windows(nouveauNom).ActivateNext
    FactOuDevis = Left(FACTUREouDEVIS, 1) & LCase(Mid(FACTUREouDEVIS, 2, Len(FACTUREouDEVIS)))
    DerniereLigne = Workbooks(fichierFactDevis).Sheets(FactOuDevis).Cells(Workbooks(fichierFactDevis).Sheets(FactOuDevis).Rows.Count, 1).End(xlUp).Row
    If FACTUREouDEVIS = "FACTURES" Then
        Workbooks(nouveauNom).Sheets(1).Range("NUM" & Left(FACTUREouDEVIS, Len(FACTUREouDEVIS) - 1)) = Workbooks(fichierFactDevis).Sheets(FactOuDevis).Range("A" & DerniereLigne)
    ElseIf FACTUREouDEVIS = "DEVIS" Then
        Workbooks(nouveauNom).Sheets(1).Range("NUM" & FACTUREouDEVIS) = Workbooks(fichierFactDevis).Sheets(FactOuDevis).Range("A" & DerniereLigne)
    End If
    
    If Weekday(Date) = 7 Then
        Workbooks(nouveauNom).Sheets(1).Range("DATEEMISSION") = Date + 2
    ElseIf Weekday(Date) = 1 Then
        Workbooks(nouveauNom).Sheets(1).Range("DATEEMISSION") = Date + 1
    ElseIf Weekday(Date) = 6 And Hour(Now) > 12 Then
        Workbooks(nouveauNom).Sheets(1).Range("DATEEMISSION") = Date + 3
    ElseIf Hour(Now) > 8 And Hour(Now) < 15 Then
        Workbooks(nouveauNom).Sheets(1).Range("DATEEMISSION") = Date
    Else: Workbooks(nouveauNom).Sheets(1).Range("DATEEMISSION") = Date + 1
    End If

    Workbooks(fichierFactDevis).Sheets(UCase(Left(FACTUREouDEVIS, 1)) & Mid(FACTUREouDEVIS, 2)).Range("B" & DerniereLigne + 1) = nomLocataire

    If ActiveSheet.Name = "Factures" Then
        Workbooks(fichierFactDevis).Sheets("Factures").Range("B" & lign) = dossierChoisi
    ElseIf ActiveSheet.Name = "Devis" Then
        Workbooks(fichierFactDevis).Sheets("Devis").Range("B" & lign) = dossierChoisi
    End If
    
    Workbooks(nouveauNom).Sheets(1).Range("NOMENTREPRISE") = Workbooks(fichierFactDevis).Sheets("Factures").Range("NOMENTREPRISE")
    With Range("NOMENTREPRISE")
        .Font.Size = 26
        .Font.Bold = True
    End With
    With Range("ENTETEBASDEPAGE")
        .Value = Range("NOMENTREPRISE") & "-" & Range("ADRESSEENTREPRISE")
        .Font.Size = 10
    End With
    Workbooks(nouveauNom).Sheets(1).Range("NOMPRENOMSIRET") = Workbooks(fichierFactDevis).Sheets("Factures").Range("NOMPRENOM") & " - " & Workbooks(fichierFactDevis).Sheets("Factures").Range("SIRET")
    Workbooks(nouveauNom).Sheets(1).Range("NOMPRENOMSIRET").Font.Size = 16
    
    Application.EnableEvents = True
    
    Exit Sub
    
Erreur:
    MsgBox "Le fichier " & nouveauNom & " est d�j� ouvert."
    Call MOINS_UN
End Sub




