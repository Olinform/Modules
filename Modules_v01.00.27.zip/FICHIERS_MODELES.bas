Attribute VB_Name = "FICHIERS_MODELES"
Function ouvrir_tous_les_fichiers_du_dossier_cible() As Variant
    With Application.FileDialog(msoFileDialogFolderPicker)
        .Title = "Choisir le dossier racine"
        If .Show <> -1 Then Exit Function
        chem1 = .SelectedItems(1) & "\"
    End With
    
    Dim listeDossiers(200) As String
    Dim listeDesModeles(100) As String
    nbDossiers = 0
    
    Debug.Print dossier
    nomDossier = Dir(chem1, vbDirectory)
    nbDossiers = 0
    Debug.Print nomDossier
    Do While nomDossier <> ""
        If nomDossier <> "." And nomDossier <> ".." Then
            If InStr(chem1 & nomDossier, ".xlsm") <> 0 And InStr(chem1 & nomDossier, "MOD") = 0 Then
                Workbooks.Open chem1 & nomDossier
                nbDossiers = nbDossiers + 1
                listeDossiers(nbDossiers) = nomDossier
            End If
        End If
        nomDossier = Dir()
    Loop
    
    ouvrir_tous_les_fichiers_du_dossier_cible = listeDossiers
    
End Function

Function ouvrir_tous_les_fichiers_modeles_FACTURES() As Variant
    chemin = recupChemin.recupCheminnNomEntreprise
    
    chem1 = chemin & Dir(chemin & "*FACTURE*", vbDirectory) & "\"
    chem2 = chem1 & Dir(chem1 & Year(Date), vbDirectory) & "\"
    chem3 = chem2 & Dir(chem2 & "*IMMO*", vbDirectory) & "\"
    
    Dim listeDossiers(200) As String
    Dim listeDesModeles(100) As String
    nbDossiers1 = 0

' pour les FACT
    nomDossierPri = Dir(chem2 & "*IMMO*", vbDirectory)
    nomDossier = Dir(chem3, vbDirectory)
    Do While nomDossier <> ""
        If nomDossier <> "." And nomDossier <> ".." Then
            If (GetAttr(chem3 & nomDossier) And vbDirectory) = vbDirectory Then
                nbDossiers1 = nbDossiers1 + 1
                listeDossiers(nbDossiers1) = nomDossier
            End If
        End If
        nomDossier = Dir()
    Loop
    
    Dim modele As String
    For i = 1 To nbDossiers1 + 2
    ' pour les agences
        If i <= nbDossiers1 Then
            suiteChemin = chem3 & listeDossiers(i) & "\FACTURES" & "\*MOD*.xlsm"
            modele = chem3 & listeDossiers(i) & "\FACTURES\" & Dir(suiteChemin)
            Workbooks.Open modele
            listeDesModeles(i) = Dir(suiteChemin)
            Debug.Print listeDesModeles(i)
        
    ' pour les ST et les CLI
        ElseIf i = nbDossiers1 + 1 Then
            nomDossierPriST = Dir(chem2 & "*SOUS*", vbDirectory) & "\"
            modeleST = Dir(chem2 & nomDossierPriST & "*FACT*MOD*.xlsm")
            chemModeleST = chem2 & nomDossierPriST & modeleST
            Workbooks.Open chemModeleST
            listeDesModeles(i) = Dir(chemModeleST)
            Debug.Print listeDesModeles(i)
            
        ElseIf i = nbDossiers1 + 2 Then
            nomDossierPriCLI = Dir(chem2 & "*CLI*", vbDirectory) & "\"
            modeleCLI = Dir(chem2 & nomDossierPriCLI & "*FACT*MOD*.xlsm")
            chemModeleCLI = chem2 & nomDossierPriCLI & modeleCLI
            Workbooks.Open chemModeleCLI
            listeDesModeles(i) = Dir(chemModeleCLI)
            Debug.Print listeDesModeles(i)
        End If
        
    Next
    
    ouvrir_tous_les_fichiers_modeles_FACTURES = listeDesModeles
    
End Function

Function ouvrir_tous_les_fichiers_modeles_DEVIS() As Variant
    chemin = recupChemin.recupCheminnNomEntreprise
    
    chem1 = chemin & Dir(chemin & "*DEV*", vbDirectory) & "\"
    chem2 = chem1 & Dir(chem1 & Year(Date), vbDirectory) & "\"
    chem3 = chem2 & Dir(chem2 & "*IMMO*", vbDirectory) & "\"
    
    Dim listeDossiers(200) As String
    Dim listeDesModeles(100) As String
    nbDossiers1 = 0

' pour les FACT
    nomDossierPri = Dir(chem2 & "*IMMO*", vbDirectory)
    nomDossier = Dir(chem3, vbDirectory)
    Do While nomDossier <> ""
        If nomDossier <> "." And nomDossier <> ".." Then
            If (GetAttr(chem3 & nomDossier) And vbDirectory) = vbDirectory Then
                nbDossiers1 = nbDossiers1 + 1
                listeDossiers(nbDossiers1) = nomDossier
            End If
        End If
        nomDossier = Dir()
    Loop
    
    Dim modele As String
    For i = 1 To nbDossiers1 + 2
    ' pour les agences
        If i <= nbDossiers1 Then
            suiteChemin = chem3 & listeDossiers(i) & "\DEVIS" & "\*MOD*.xlsm"
            modele = chem3 & listeDossiers(i) & "\DEVIS\" & Dir(suiteChemin)
            Workbooks.Open modele
            listeDesModeles(i) = Dir(suiteChemin)
            Debug.Print listeDesModeles(i)
        
    ' pour les ST et les CLI
        ElseIf i = nbDossiers1 + 1 Then
            nomDossierPriST = Dir(chem2 & "*SOUS*", vbDirectory) & "\"
            modeleST = Dir(chem2 & nomDossierPriST & "*DEV*MOD*.xlsm")
            chemModeleST = chem2 & nomDossierPriST & modeleST
            Workbooks.Open chemModeleST
            listeDesModeles(i) = Dir(chemModeleST)
            Debug.Print listeDesModeles(i)
            
        ElseIf i = nbDossiers1 + 2 Then
            nomDossierPriCLI = Dir(chem2 & "*CLI*", vbDirectory) & "\"
            modeleCLI = Dir(chem2 & nomDossierPriCLI & "*DEV*MOD*.xlsm")
            chemModeleCLI = chem2 & nomDossierPriCLI & modeleCLI
            Workbooks.Open chemModeleCLI
            listeDesModeles(i) = Dir(chemModeleCLI)
            Debug.Print listeDesModeles(i)
        End If
        
    Next
    
    ouvrir_tous_les_fichiers_modeles_DEVIS = listeDesModeles
    
End Function

Sub tout_Fermer()
    Dim bol As Boolean
    k = Windows.Count
    bol = MsgBox("On enregistre avant de fermer tous les mod�les ?", vbYesNo)
ici:
    peutetrefin = 0
    For i = 1 To k
        If k < i Then
            Exit For
'        ElseIf InStr(Windows(i).Caption, "-IMMONATURE-") <> 0 Then
        ElseIf InStr(Application.Workbooks(i).Name, "MODE") <> 0 Then
            Dim nomWB As String
            Debug.Print Workbooks(i).Name
            nomWB = Workbooks(i).Name
            Workbooks(nomWB).Close SaveChanges:=bol
            i = i - 1
            k = k - 1
        ElseIf InStr(Windows(i).Caption, Year(Date)) <> 0 Then
            peutetrefin = peutetrefin + 1
        End If
    Next
    
    If peutetrefin = k Then
        Exit Sub
    ElseIf peutetrefin > 0 Then
        GoTo ici
    End If
    
End Sub

Sub copier_coller_les_instructions()
    
    listeDesModeles = ouvrir_tous_les_fichiers_modeles_FACTURES: GoTo here
'    listeDesModeles = ouvrir_tous_les_fichiers_modeles_DEVIS: GoTo here
'    listeDesModeles = ouvrir_tous_les_fichiers_du_dossier_cible: GoTo here
    
    MsgBox "Manque un truc": Exit Sub
    
here:
    Dim codeMod As Object
    Dim LeFich
    Dim sauvegarde(20) As Variant
    
la:
    Application.EnableEvents = False
    Chx_Client.ListBox1.AddItem "------------ FICHIER SOURCE ------------"
    Chx_Client.ListBox1.AddItem
    For h = 1 To Windows.Count
        Chx_Client.ListBox1.AddItem Windows(h).Caption
    Next h
    Chx_Client.ListBox1.AddItem
    Chx_Client.ListBox1.AddItem " ------ METTRE A JOUR LA LISTE ------"
    
    ' export du Module1
    Application.EnableEvents = True
    Chx_Client.Show vbModal
    If CaptionChoisieCopieColleMODULS = "" Then End
    If InStr(CaptionChoisieCopieColleMODULS, "METTRE A JOUR LA LISTE") <> 0 Then
        GoTo la
    End If
    
    feuilleACopier = Array("ThisWorkbook", Workbooks(CaptionChoisieCopieColleMODULS).Sheets("Feuil1").CodeName)
    
    For Each LeFich In Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents
'            Debug.Print LeFich.Name
        Select Case LeFich.Type
            Case 1
                Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents(LeFich.Name).EXPORT Environ("TEMP") & "\" & LeFich.Name & ".bas"
                Debug.Print Environ("temp") & "\" & LeFich.Name & ".bas"
'                    Exit For
            Case 2
'                Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents(LeFich.Name).Export Environ("temp") & "\" & LeFich.Name & ".cls"
            Case 3
                Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents(LeFich.Name).EXPORT Environ("TEMP") & "\" & LeFich.Name & ".frm"
                Debug.Print Environ("temp") & "\" & LeFich.Name & ".frm"
'                    Exit For
            Case 100
'                Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents(LeFich.Name).Export Environ("temp") & "\" & LeFich.Name & ".cls"
        End Select
    Next
        
    
    For i = 1 To UBound(listeDesModeles)
        
        If listeDesModeles(i) = "" Then Exit For
        nomWorkBAOuvrir = listeDesModeles(i)
    
        feuilleAColler = Array("ThisWorkbook", Workbooks(nomWorkBAOuvrir).Sheets("Feuil1").CodeName)
        
        On Error GoTo ici
        Workbooks(nomWorkBAOuvrir).Activate
            
        For k = 0 To UBound(feuilleACopier)
ici:
            Dim CNFeuil As String
            Set codeMod = Workbooks(nomWorkBAOuvrir).VBProject.VBComponents(feuilleAColler(k)).CodeModule
            LineNum = Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents(feuilleACopier(k)).CodeModule.CountOfLines
            
            codeMod.DeleteLines 1, codeMod.CountOfLines
            
            For m = 1 To LineNum
                If m > 2 Then
    '                MsgBox Right(workbooks("20241203_Calendrier2025_TEST_20_avec taches.xlsm").VBProject.VBComponents(tabComp(k)).CodeModule.Lines(i - 2, 1), 1)
                
                    If Right(Workbooks(nomWorkBAOuvrir).VBProject.VBComponents(feuilleAColler(k)).CodeModule.Lines(m - 2, 1), 1) = "_" Then
                        Workbooks(nomWorkBAOuvrir).VBProject.VBComponents(feuilleAColler(k)).CodeModule.DeleteLines (m - 1)
                    End If
                End If
                
                codeMod.InsertLines LineNum, Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents(feuilleACopier(k)).CodeModule.Lines(m, 1)
            Next m
        Next k
        
        chemin = Environ("temp") & "\"
    '    chemin = "C:\Users\olivi\Documents\(00) - TRAVAIL\00 - OLINFORM BATIM\00-EXERCICE DE L'ACTIVITE\00-DOCUMENTS DE SUIVI DE L'EXERCICE\macros - modules export�s\TOUS modules version FINALE\"
        j = 0
    
        For Each LeFich In Workbooks(CaptionChoisieCopieColleMODULS).VBProject.VBComponents
            Debug.Print LeFich.Name
            On Error Resume Next
            Select Case LeFich.Type
                Case 1
                    Workbooks(nomWorkBAOuvrir).VBProject.VBComponents.Remove _
                        Workbooks(nomWorkBAOuvrir).VBProject.VBComponents(LeFich.Name)
                    Workbooks(nomWorkBAOuvrir).VBProject.VBComponents.Import chemin & LeFich.Name & ".bas"
                Case 2
'                    ThisWorkbook.VBProject.VBComponents(LeFich.Name).EXPORT chemin & LeFich.Name & ".cls"
                Case 3
                    Workbooks(nomWorkBAOuvrir).VBProject.VBComponents.Remove _
                        Workbooks(nomWorkBAOuvrir).VBProject.VBComponents(LeFich.Name)
                    Workbooks(nomWorkBAOuvrir).VBProject.VBComponents.Import chemin & LeFich.Name & ".frm"
                Case 100
'                    ThisWorkbook.VBProject.VBComponents(LeFich.Name).EXPORT chemin & LeFich.Name & ".cls"
            End Select
            On Error GoTo 0
        Next
    Next i
    MsgBox "Termin�"

    If MsgBox("On ferme tous les mod�les ?", vbYesNo) = vbYes Then Call tout_Fermer

End Sub

'Function ExporterModules()
'
'    Dim LeFich
'    Dim sauvegarde(20) As Variant
'    chemin = Environ("temp")
''    chemin = "C:\Users\olivi\Documents\(00) - TRAVAIL\00 - OLINFORM BATIM\00-EXERCICE DE L'ACTIVITE\00-DOCUMENTS DE SUIVI DE L'EXERCICE\macros - modules export�s\TOUS modules version FINALE\"
'    j = 0
'
'    For Each LeFich In ThisWorkbook.VBProject.VBComponents
'        Debug.Print LeFich.Name
'        Select Case LeFich.Type
'            Case 1
'                ThisWorkbook.VBProject.VBComponents(LeFich.Name).Export chemin & LeFich.Name & ".bas"
'            Case 2
'                ThisWorkbook.VBProject.VBComponents(LeFich.Name).Export chemin & LeFich.Name & ".cls"
'            Case 3
'                sauvegarde(j) = "module1.frm"
'                j = j + 1
'                ThisWorkbook.VBProject.VBComponents(LeFich.Name).Export Environ("temp") & "\" & LeFich.Name & ".frm"
'                ThisWorkbook.VBProject.VBComponents(LeFich.Name).Export chemin & LeFich.Name & ".frm"
'            Case 100
'                ThisWorkbook.VBProject.VBComponents(LeFich.Name).Export chemin & LeFich.Name & ".cls"
'        End Select
'    Next
'    ExporterModules = sauvegarde
'End Function
