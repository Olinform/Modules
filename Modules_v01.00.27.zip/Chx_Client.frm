VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} Chx_Client 
   Caption         =   "QUI"
   ClientHeight    =   3120
   ClientLeft      =   435
   ClientTop       =   1620
   ClientWidth     =   5490
   OleObjectBlob   =   "Chx_Client.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "Chx_Client"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub retourEnArriere_Click()
    CaptionChoisieCLIENT = "RETOUR EN ARRIERE"
    Unload Me
End Sub


Private Sub userform_activate()
    ' Position HAUT-GAUCHE qui FONCTIONNE � 100%
    Me.Left = (Application.Width / 2) - (Me.Width / 2)
    Me.Top = (Application.Height / 2) - (Me.Height / 2)

End Sub

Private Sub UserForm_Initialize()
    Me.Caption = "QUI ?"
    Me.ListBox1.List = Array()
    With Me.ListBox1.Font
        .Name = "Arial"           ' Police (optionnel)
        .Size = 13              ' ? TAILLE 12 (augmente � 14, 16...)
    End With

    ' ? La ListBox est d�j� remplie par le code appelant
End Sub

Private Sub ListBox1_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    
    Debug.Print Me.ListBox1.ListIndex
    If Me.Visible = False Then
        Chx_Client.ListBox1.AddItem "------------ ANNULE ------------"
        Exit Sub
    ElseIf Me.ListBox1.ListIndex >= 0 And _
    InStr(Me.ListBox1.List(0), "FICHIER SOURCE") = 0 Then
        CaptionChoisieCLIENT = Me.ListBox1.Value  ' ? variable globale
        Unload Me
    ElseIf InStr(Me.ListBox1.List(0), "FICHIER SOURCE") <> 0 Then
        CaptionChoisieCopieColleMODULS = Me.ListBox1.Value
        Unload Me
    End If
End Sub

Private Sub userform_Terminate()

    Application.EnableEvents = False
    On Error Resume Next
    If ActiveSheet.Name = "Factures" Then Range("A2").Select
    Application.EnableEvents = True
    On Error GoTo 0
    
End Sub
