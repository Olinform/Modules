Attribute VB_Name = "CREER_ARBORESCENCE"
Sub CreerArborescence()
    Dim dossierRacine As String, i As Long
    
    anneeIndiquee = Split(Sheets("Arborescence").Cells(4, "A").Value, "\")(1)
    annee = InputBox("Gestionnaire de facture pour l'ann�e ... ?")
    If annee = "" Then Exit Sub
    
    Sheets("Arborescence").Range("A:A").Replace What:=anneeIndiquee, Replacement:=annee, _
              LookAt:=xlPart, SearchOrder:=xlByRows, MatchCase:=False

    ' 1. S�lection dossier racine
    With Application.FileDialog(msoFileDialogFolderPicker)
        .Title = "Choisir le dossier racine"
        If .Show <> -1 Then Exit Sub
        dossierRacine = .SelectedItems(1)
    End With
    
    If Right(dossierRacine, 1) <> "\" Then dossierRacine = dossierRacine & "\"
    
    rep = MsgBox("Passer la copie des mod�les ?", vbYesNo)
    If rep = vbYes Then GoTo mail
    ' 2. Cr�ation depuis feuille cach�e "Arborescence" (colonne A)
    With Sheets("Arborescence")
        For i = 1 To .Cells(.Rows.Count, "A").End(xlUp).Row
            If .Cells(i, "A").Value <> "" Then
                dossier = dossierRacine & .Cells(i, "A").Value & "\"
                CreeDossier dossierRacine & .Cells(i, "A").Value
' cr�er les fichiers mod�les pour Factures
                If UBound(Split(.Cells(i, "A").Value, "\")) > 3 And i < 20 Then
                    If fichierFacturesImmoModele = "" And InStr(.Cells(i, "A").Value, "\FACTURES") <> 0 Then

                        With Application.FileDialog(msoFileDialogFilePicker)
                            .Title = "O� se trouve le fichier EXCEL mod�le de FACTURES pour agences immobil�res ?"
                            .Filters.Clear
                            .InitialView = msoFileDialogViewDetails
                            .AllowMultiSelect = False
                            If .Show <> -1 Then Exit Sub
                            fichierFacturesImmoModele = .SelectedItems(1)
                        End With
                        Call CopierFichierFSO(fichierFacturesImmoModele, dossier & "00-FACT_IMMO1_MODELE.xlsm")
                        ch = 1
                        
                    ElseIf fichierDevisImmoModele = "" And InStr(.Cells(i, "A").Value, "\DEVIS") <> 0 Then

                        With Application.FileDialog(msoFileDialogFilePicker)
                            .Title = "O� se trouve le fichier EXCEL mod�le de DEVIS pour agences immobil�res ?"
                            .Filters.Clear
                            .InitialView = msoFileDialogViewDetails
                            .AllowMultiSelect = False
                            If .Show <> -1 Then Exit Sub
                            fichierDevisImmoModele = .SelectedItems(1)
                        End With
                        Call CopierFichierFSO(fichierDevisImmoModele, dossier & "00-DEV_IMMO1_MODELE.xlsm")
                        
                    ElseIf InStr(.Cells(i, "A").Value, "IMMO") <> 0 And _
                    InStr(.Cells(i, "A").Value, "\FACTURES") <> 0 And _
                    fichierFacturesImmoModele <> "" Then
                        Call CopierFichierFSO(fichierFacturesImmoModele, dossier & "00-FACT_IMMO" & im + 1 & "_MODELE.xlsm")
                        If im < 2 Then ch = 1
                    ElseIf InStr(.Cells(i, "A").Value, "IMMO") <> 0 And _
                    InStr(.Cells(i, "A").Value, "\DEVIS") <> 0 And _
                    fichierDevisImmoModele <> "" Then
                        Call CopierFichierFSO(fichierDevisImmoModele, dossier & "00-DEV_IMMO" & im + 1 & "_MODELE.xlsm")
                    End If
                    If ch = 1 Then If im >= 1 Then im = im + 1 Else im = 1
                    ch = 0
                    
                ElseIf i > 19 Then
                    If InStr(.Cells(i, "A").Value, "SOUS-TRAI") <> 0 And InStr(.Cells(i, "A").Value, "\FACTURES") <> 0 And _
                    fichierFacturesSTModele = "" Then
                        With Application.FileDialog(msoFileDialogFilePicker)
                            .Title = "O� se trouve le fichier EXCEL mod�le de FACTURES pour sous-traitants ?"
                            .Filters.Clear
                            .InitialView = msoFileDialogViewDetails
                            .AllowMultiSelect = False
                            If .Show <> -1 Then Exit Sub
                            fichierFacturesSTModele = .SelectedItems(1)
                        End With
                        Call CopierFichierFSO(fichierFacturesSTModele, dossierRacine & Split(.Cells(i, "A").Value, "\")(0) & "\" & _
                        Split(.Cells(i, "A").Value, "\")(1) & "\" & Split(.Cells(i, "A").Value, "\")(2) & "\" & "FACT_ST_MODELE.xlsm")
                        
                    ElseIf InStr(.Cells(i, "A").Value, "CLIENTS DIR") <> 0 And _
                    InStr(.Cells(i, "A").Value, "\FACTURES") <> 0 And _
                    fichierFacturesCLIModele = "" Then
                        With Application.FileDialog(msoFileDialogFilePicker)
                            .Title = "O� se trouve le fichier EXCEL mod�le de FACTURES pour les clients directs ?"
                            .Filters.Clear
                            .InitialView = msoFileDialogViewDetails
                            .AllowMultiSelect = False
                            If .Show <> -1 Then Exit Sub
                            fichierFacturesCLIModele = .SelectedItems(1)
                        End With
                        Call CopierFichierFSO(fichierFacturesCLIModele, dossierRacine & Split(.Cells(i, "A").Value, "\")(0) & "\" & _
                        Split(.Cells(i, "A").Value, "\")(1) & "\" & Split(.Cells(i, "A").Value, "\")(2) & "\" & "FACT_CLI_MODELE.xlsm")
                            
                    ElseIf InStr(.Cells(i, "A").Value, "SOUS-TRAI") <> 0 And _
                    InStr(.Cells(i, "A").Value, "\DEVIS") <> 0 And _
                    fichierDevisSTModele = "" Then
                        
                        With Application.FileDialog(msoFileDialogFilePicker)
                            .Title = "O� se trouve le fichier EXCEL mod�le de DEVIS pour sous-traitants ?"
                            .Filters.Clear
                            .InitialView = msoFileDialogViewDetails
                            .AllowMultiSelect = False
                            If .Show <> -1 Then Exit Sub
                            fichierDevisSTModele = .SelectedItems(1)
                        End With
                        Call CopierFichierFSO(fichierDevisSTModele, dossierRacine & Split(.Cells(i, "A").Value, "\")(0) & "\" & _
                        Split(.Cells(i, "A").Value, "\")(1) & "\" & Split(.Cells(i, "A").Value, "\")(2) & "\" & "DEV_ST_MODELE.xlsm")
                        
                        
                    ElseIf InStr(.Cells(i, "A").Value, "CLIENTS DIR") <> 0 And _
                    InStr(.Cells(i, "A").Value, "\DEVIS") <> 0 And _
                    fichierDevisCLIModele = "" Then
                        With Application.FileDialog(msoFileDialogFilePicker)
                            .Title = "O� se trouve le fichier EXCEL mod�le de DEVIS pour les clients directs ?"
                            .Filters.Clear
                            .InitialView = msoFileDialogViewDetails
                            .AllowMultiSelect = False
                            If .Show <> -1 Then Exit Sub
                            fichierDevisCLIModele = .SelectedItems(1)
                        End With
                        Call CopierFichierFSO(fichierDevisCLIModele, dossierRacine & Split(.Cells(i, "A").Value, "\")(0) & "\" & _
                        Split(.Cells(i, "A").Value, "\")(1) & "\" & Split(.Cells(i, "A").Value, "\")(2) & "\" & "DEV_CLI_MODELE.xlsm")
                        
                    End If
                End If
            End If
        Next i
    End With
    
mail:
    Dim fso As Object, fichier As Object
    
    ' Demander l'adresse email
    email = InputBox("Entrez votre adresse email :", "Cr�ation fichier mails")
    
    If email = "" Then Exit Sub

'mailsimmo.txt
    nomFichier = "mailsimmo.txt"
    cheminNomEntre = recupCheminnNomEntreprise
    cheminMailsImmo = cheminNomEntre & Dir(cheminNomEntre & "*FACTURES-DEVIS*", vbDirectory) & "\" & annee & "\0 - AGENCES IMMO\" & nomFichier

    Set fso = CreateObject("Scripting.FileSystemObject")
    Set fichier = fso.CreateTextFile(cheminMailsImmo, True)

    fichier.WriteLine "MOI"
    fichier.WriteLine email
    fichier.WriteLine
        
'mailST.txt

    nomFichier = "mailsST.txt"
    cheminNomEntre = recupCheminnNomEntreprise
    cheminMailsST = cheminNomEntre & Dir(cheminNomEntre & "*FACTURES-DEVIS*", vbDirectory) & "\" & annee & "\1 - SOUS-TRAITANCE\" & nomFichier
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set fichier = fso.CreateTextFile(cheminMailsST, True)

    fichier.WriteLine "MOI"
    fichier.WriteLine email
    fichier.WriteLine
    
'mailCLI.txt

    nomFichier = "mailsCLI.txt"
    cheminNomEntre = recupCheminnNomEntreprise
    cheminMailsCLI = cheminNomEntre & Dir(cheminNomEntre & "*FACTURES-DEVIS*", vbDirectory) & "\" & annee & "\2 - CLIENTS DIRECTS\" & nomFichier

    Set fso = CreateObject("Scripting.FileSystemObject")
    Set fichier = fso.CreateTextFile(cheminMailsCLI, True)

    fichier.WriteLine "MOI"
    fichier.WriteLine email
    fichier.WriteLine

    
    MsgBox "Arborescence cr��e !"
End Sub

Private Sub CreeDossier(chemin As String)
    On Error Resume Next
    MkDir chemin
    On Error GoTo 0
End Sub

Sub CopierFichierFSO(fichierACopier, dossierCible)
    Debug.Print fichierACopier & Chr(10) & dossierCible
    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    fso.CopyFile fichierACopier, dossierCible, True
End Sub


Sub CacherFeuilleArbo()
    Sheets("Arborescence").Visible = xlSheetVeryHidden  ' Tr�s cach�e
'    Sheets("Arborescence").Visible = xlSheetVisible
End Sub

Sub copierCollerLesModelesDansLesDossiers()

    chemin = recupChemin.recupCheminnNomEntreprise
    
    chem1 = chemin & Dir(chemin & "*FACTURE*", vbDirectory) & "\"
    chem2 = chem1 & Dir(chem1 & Year(Date), vbDirectory) & "\"
    chem3 = chem2 & Dir(chem2 & "*IMMO*", vbDirectory) & "\"
    
    Dim listeDossiers(200) As String
    Dim listeDesModeles(100) As String
    nbDossiers = 0

' pour les agences
    nomDossierPri = Dir(chem2 & "*IMMO*", vbDirectory)
    nomDossier = Dir(chem3, vbDirectory)
    Do While nomDossier <> ""
        If nomDossier <> "." And nomDossier <> ".." Then
            If (GetAttr(chem3 & nomDossier) And vbDirectory) = vbDirectory Then
                nbDossiers = nbDossiers + 1
                listeDossiers(nbDossiers) = nomDossier
            End If
        End If
        nomDossier = Dir()
    Loop
    
    Dim modele As String
    For i = 1 To nbDossiers + 2
    ' pour les agences
        If i <= nbDossiers Then
            suiteChemin = chem3 & listeDossiers(i) & "\FACTURES" & "\*MOD*.xlsm"
            modele = chem3 & listeDossiers(i) & "\FACTURES\" & Dir(suiteChemin)
            Workbooks.Open modele
            listeDesModeles(i) = Dir(suiteChemin)
        
    ' pour les ST et les CLI
        ElseIf i = nbDossiers + 1 Then
            nomDossierPriST = Dir(chem2 & "*SOUS*", vbDirectory) & "\"
            modeleST = Dir(chem2 & nomDossierPriST & "*FACT*MOD*.xlsm")
            chemModeleST = chem2 & nomDossierPriST & modeleST
            Workbooks.Open chemModeleST
            listeDesModeles(i) = Dir(chemModeleST)
            Debug.Print listeDesModeles(i)
            
        ElseIf i = nbDossiers + 2 Then
            nomDossierPriCLI = Dir(chem2 & "*CLI*", vbDirectory) & "\"
            modeleCLI = Dir(chem2 & nomDossierPriCLI & "*FACT*MOD*.xlsm")
            chemModeleCLI = chem2 & nomDossierPriCLI & modeleCLI
            Workbooks.Open chemModeleCLI
            listeDesModeles(i) = Dir(chemModeleCLI)
            Debug.Print listeDesModeles(i)
        End If
        
    Next

End Sub
