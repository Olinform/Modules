VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} Nouv_Devis 
   Caption         =   "UserForm1"
   ClientHeight    =   3120
   ClientLeft      =   105
   ClientTop       =   450
   ClientWidth     =   4815
   OleObjectBlob   =   "Nouv_Devis.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "Nouv_Devis"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub userform_Terminate()
    Application.EnableEvents = False
    If ActiveSheet.Name = "Devis" Then ActiveCell.Select
    Application.EnableEvents = True
End Sub

Private Sub Factures_Click()
    Sheets("Factures").Activate
    Nouvelle_Facture.Show vbModal = False
End Sub

Private Sub sauvegarde_Click()
    ActiveWorkbook.Save
End Sub

Private Sub MoinsUn_Click()
    Call MOINS_UN.MOINS_UN
End Sub

Private Sub PlusUn_Click()

    lignDerDevis = Cells(Rows.Count, 1).End(xlUp).Row
    
    Rows(lignDerDevis & ":" & lignDerDevis + 2).Copy
    Rows(lignDerDevis + 3).Insert
    Range("A" & lignDerDevis + 3).Hyperlinks.Delete
    
    depPLB = "_" & Split(Range("A" & lignDerDevis + 3), "_")(2) & "_" & Split(Range("A" & lignDerDevis + 3), "_")(3)
    Mois = Mid(Range("A" & lignDerDevis + 3), 7, 2)
    If Mois <> Month(Date) And Mois = 12 Then annee = Year(Date): Mois = Month(Date) Else annee = Year(Date)
    
    If Len(Mois) = 1 Then Mois = "0" & Mois
    
    caseNumFacture = Split(Range("A" & lignDerDevis + 3), "_")(1)
    caseNumFacture = annee & Mois & Mid(caseNumFacture, 7, Len(caseNumFacture) - 8)
    Range("A" & lignDerDevis + 3) = "D_" & caseNumFacture
    
'    If Len(caseNumFacture) > 3 Then caseNumFacture = Left(caseNumFacture, 3)
     
    Numfact = CDbl(Right(caseNumFacture, 3))
    If Len(Numfact) = 2 Then
        Range("A" & lignDerDevis + 3) = Left(Range("A" & lignDerDevis + 3), 8) & "0" & Numfact + 1
        Range("A" & lignDerDevis + 3).Borders(xlEdgeTop).LineStyle = True
        Range("A" & lignDerDevis + 3).Characters(Start:=10, Length:=2).Font.Color = vbRed
    Else:
        Range("A" & lignDerDevis + 3) = Left(Range("A" & lignDerDevis + 3), 8) & Numfact + 1
        Range("A" & lignDerDevis + 3).Borders(xlEdgeTop).LineStyle = True
        Range("A" & lignDerDevis + 3).Characters(Start:=9, Length:=3).Font.Color = vbRed
    End If
    
    Range("A" & lignDerDevis + 3).Font.Bold = True
    Range("B" & lignDerDevis + 3 & ":" & "B" & lignDerDevis + 4).ClearContents
    Range("C" & lignDerDevis + 3 & ":E" & lignDerDevis + 3).ClearContents
    Range("G" & lignDerDevis + 3).ClearContents
    Range("M" & lignDerDevis + 3).ClearContents
    Range("O" & lignDerDevis + 3 & ":Q" & lignDerDevis + 3).ClearContents
    
    ActiveSheet.Calculate
    
    typeclient = CHOISIR_CLIENT.ChoisirDossierTravailTableau("", lignDerDevis + 3)
    If typeclient <> "" Then _
        Range("B" & lignDerDevis + 3) = CHOISIR_CLIENT.ChoisirDossierTravailTableau(typeclient, lignDerDevis + 3)

    dMois = Date ' -> 01/01/2026
    dDeb = DateSerial(Year(dMois), Month(dMois), 1)
    dFin = DateSerial(Year(dMois), Month(dMois) + 1, 0)
    
    'Net envisag�
    Range("N2").FormulaLocal = "=SOMME.SI.ENS(N3:N" & lignDerDevis + 3 & _
    ";E3:E" & lignDerDevis + 3 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";E3:E" & lignDerDevis + 3 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";O3:O" & lignDerDevis + 3 & _
    ";"""";" & _
    "P3:P" & lignDerDevis + 3 & _
    ";"""")+" & _
    "SOMME.SI.ENS(N3:N" & lignDerDevis + 3 & _
    ";H3:H" & lignDerDevis + 3 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";H3:H" & lignDerDevis + 3 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";O3:O" & lignDerDevis + 3 & _
    ";"""";" & _
    "P3:P" & lignDerDevis + 3 & _
    ";"""";" & _
    "Q3:Q" & lignDerDevis + 3 & _
    ";"""")"


End Sub
Private Function GetDossierParent() As String
    GetDossierParent = Environ("USERPROFILE") & "\Documents\(00) - TRAVAIL\00 - BATIMENT\01-OB PLOMBERIE\00 - FACTURES-DEVIS\" & Year(Date) & "\"
End Function


Private Sub CommandButton1_Click()
    Dim fso As Object, dossier As Object, sousDossier As Object
    Dim CheminDossier As String
    
    CheminDossier = GetDossierParent() & "0 - AGENCES IMMO"
    Me.ListBox2.Clear
    
    ' AJOUT DU NOM DU BOUTON EN 1ER
    Me.ListBox2.AddItem "=== AGENCES IMMOBILI�RES ==="
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(CheminDossier) Then
        Set dossier = fso.GetFolder(CheminDossier)
        For Each sousDossier In dossier.SubFolders
            Me.ListBox2.AddItem sousDossier.Name
        Next sousDossier
    Else
        MsgBox "Dossier non trouv� : " & CheminDossier
    End If
    Set fso = Nothing
End Sub

Private Sub CommandButton2_Click()
    Dim fso As Object, dossier As Object, sousDossier As Object
    Dim CheminDossier As String
    
    CheminDossier = GetDossierParent() & "1 - SOUS-TRAITANCE"
    Me.ListBox2.Clear
    
    ' AJOUT DU NOM DU BOUTON EN 1ER
    Me.ListBox2.AddItem "=== SOUS-TRAITANCE ==="
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(CheminDossier) Then
        Set dossier = fso.GetFolder(CheminDossier)
        For Each sousDossier In dossier.SubFolders
            Me.ListBox2.AddItem sousDossier.Name
        Next sousDossier
    Else
        MsgBox "Dossier non trouv� : " & CheminDossier
    End If
    Set fso = Nothing
End Sub

Private Sub CommandButton3_Click()
    Dim fso As Object, dossier As Object, sousDossier As Object
    Dim CheminDossier As String
    
    CheminDossier = GetDossierParent() & "2 - CLIENTS DIRECTS\"
    Me.ListBox2.Clear
    
    ' AJOUT DU NOM DU BOUTON EN 1ER
    Me.ListBox2.AddItem "=== CLIENTS DIRECTS ==="
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(CheminDossier) Then
        Set dossier = fso.GetFolder(CheminDossier)
        For Each sousDossier In dossier.SubFolders
            Me.ListBox2.AddItem sousDossier.Name
        Next sousDossier
    Else
        MsgBox "Dossier non trouv� : " & CheminDossier
    End If
    Set fso = Nothing
End Sub


Private Sub ListBox2_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Dim NomSousDossier As String, CheminFactures As String
    Dim dossierRacine As String
    
    NomSousDossier = Me.ListBox2.Value
    
    If Me.ListBox2.ListIndex = 0 Then
        If InStr(1, Me.ListBox2.List(0), "AGENCES") > 0 Then
            dossierRacine = GetDossierParent() & "0 - AGENCES IMMO\"
            chemin = dossierRacine
        ElseIf InStr(1, Me.ListBox2.List(0), "SOUS-TRAITANCE") > 0 Then
            dossierRacine = GetDossierParent() & "1 - SOUS-TRAITANCE\"
            chemin = dossierRacine
        Else
            dossierRacine = GetDossierParent() & "2 - CLIENTS DIRECTS\"
            chemin = dossierRacine
        End If
        shell "explorer.exe """ & chemin & """", vbNormalFocus
    ElseIf Me.ListBox2.ListIndex > 0 Then  ' > 0 = ignore le 1er �l�ment (titre)
        ' D�tecte le dossier via le 1er �l�ment (titre)
        
        If InStr(1, Me.ListBox2.List(0), "AGENCES") > 0 Then
            dossierRacine = GetDossierParent() & "0 - AGENCES IMMO\"
            CheminFactures = dossierRacine & NomSousDossier & "\DEVIS"
        ElseIf InStr(1, Me.ListBox2.List(0), "SOUS-TRAITANCE") > 0 Then
            dossierRacine = GetDossierParent() & "1 - SOUS-TRAITANCE\"
            CheminFactures = dossierRacine & NomSousDossier & "\DEVIS"
        Else
            dossierRacine = GetDossierParent() & "2 - CLIENTS DIRECTS\"
            CheminFactures = dossierRacine & NomSousDossier
        End If
        
        If Dir(CheminFactures, vbDirectory) <> "" Then
            shell "explorer.exe """ & CheminFactures & """", vbNormalFocus
        Else
            MsgBox "Dossier FACTURES non trouv� : " & CheminFactures
        End If
    End If
End Sub


Private Sub userform_activate()
    ' Position HAUT-GAUCHE qui FONCTIONNE � 100%
    Me.Left = 10
    Me.Top = 10
End Sub
