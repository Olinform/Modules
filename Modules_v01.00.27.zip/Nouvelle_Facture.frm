VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} Nouvelle_Facture 
   Caption         =   "FACTURES"
   ClientHeight    =   5490
   ClientLeft      =   255
   ClientTop       =   990
   ClientWidth     =   6390
   OleObjectBlob   =   "Nouvelle_Facture.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "Nouvelle_Facture"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Public chemin As String

Private Sub EnregistrerUneSauvegarde_Click()
    Dim fso As Object, cheminBase As String, cheminSauvegarde As String
    Dim nomFichier As String
    
    ' D�finir les chemins (adaptez selon votre structure)
    Set fso = CreateObject("Scripting.FileSystemObject")

    chemin = recupCheminnNomEntreprise
    chemin = chemin & Dir(chemin & "*EXCEL*", vbDirectory) & "\"
    cheminSauvegarde = chemin & "sauvegardes\"
    nomFichier = ThisWorkbook.Name
    
    ' Ouvrir le dossier sauvegardes
    shell "explorer.exe """ & cheminSauvegarde & """", vbNormalFocus
    
    ' D�calage des sauvegardes (old3 <- old2 <- old1)
'    On Error Resume Next
'    fso.DeleteFile cheminSauvegarde & Split(nomFichier, ".")(0) & " old3.xlsm"  ' Efface old3
'    Name cheminSauvegarde & Split(nomFichier, ".")(0) & " old2.xlsm" As cheminSauvegarde & Split(nomFichier, ".")(0) & " old3.xlsm"
'    Name cheminSauvegarde & Split(nomFichier, ".")(0) & " old1.xlsm" As cheminSauvegarde & Split(nomFichier, ".")(0) & " old2.xlsm"
'    Name cheminSauvegarde & Split(nomFichier, ".")(0) & " old.xlsm" As cheminSauvegarde & Split(nomFichier, ".")(0) & " old1.xlsm"
'    On Error GoTo 0
    
    ' Copie nouvelle sauvegarde
'    ThisWorkbook.SaveAs cheminSauvegarde & Split(nomFichier, ".")(0) & " old.xlsm"
    ThisWorkbook.Save
    
    Dim nomDestination As String
    
    ' Initialisation FSO
    Set fso = CreateObject("Scripting.FileSystemObject")
    
    ' 1. G�n�rer le nom unique (avec (+1), (+2) si besoin)
    nomDestination = GetNomUnique(cheminSauvegarde & Split(nomFichier, ".xlsm")(0) & " sauve.xlsm", fso)
    
    ' 2. Copier le fichier vers le nom unique g�n�r�
    Debug.Print chemin & nomFichier
    fso.CopyFile chemin & nomFichier, nomDestination
    
    Set fso = Nothing

    
    MsgBox "Sauvegarde cr��e !", vbInformation
End Sub

' --- Fonction Helper pour g�n�rer un nom unique ---
Private Function GetNomUnique(destPath As String, fso As Object) As String
    Dim baseName As String, ext As String
    Dim chemComplet As String
    Dim compteur As Long
    
    ' S�parer le nom de base et l'extension
    ' Ex: "Donn�es sauve.xlsm" -> base="Donn�es sauve", ext=".xlsm"
    ext = "." & Right(destPath, Len(destPath) - InStrRev(destPath, "."))
    baseName = Left(destPath, Len(destPath) - Len(ext))
    
    ' V�rifier si le fichier existe d�j�
    chemComplet = destPath
    If fso.FileExists(chemComplet) Then
        compteur = 1
        Do While fso.FileExists(chemComplet)
            ' Ins�rer (+compteur) juste avant l'extension
            chemComplet = baseName & " (" & compteur & ")" & ext
            compteur = compteur + 1
        Loop
    End If
    
    GetNomUnique = chemComplet
End Function

Private Sub EXCELS_Click()
    chemin = recupCheminnNomEntreprise
    chemin = chemin & Dir(chemin & "*EXCEL*", vbDirectory)
    Debug.Print chemin
    shell "explorer.exe """ & chemin & """", 1
End Sub

Private Sub Fournisseurs_Click()
    chemin = recupCheminnNomEntreprise
    chemin = chemin & Dir(chemin & "*EXCEL*", vbDirectory)
    shell "explorer.exe """ & chemin & """", 1
End Sub

Private Sub SupprFinDeMois_Click()
    lign = Cells(Rows.Count, 1).End(xlUp).Row
    
    If InStr(Range("A" & lign), "F_20") <> 0 Then Exit Sub
    If InStr(Range("A" & lign), "F_20") <> 0 Then Exit Sub
    
    Application.EnableEvents = False
    
    lign = Cells(Rows.Count, 1).End(xlUp).Row
    vide = 1
    For i = 1 To 10
        If Range("A" & lign - i) <> "" Then vide = 0
    Next i
    If vide = 1 Then Rows(lign - 10 & ":" & lign).Delete
    
    Call RecalculMoisEnCours("oui")
    
    Application.EnableEvents = True
    
    Call Init_ListBox3Et1
    
End Sub


Private Sub userform_Terminate()
'    Application.EnableEvents = False
'    If ActiveSheet.Name = "Factures" Then Range("A" & 5).Select
'    Application.EnableEvents = True
End Sub



Private Sub Devis_Click()
    Sheets("Devis").Activate
    Nouv_Devis.Show vbModal = False
End Sub


Private Sub FinDeMois_Click()
    
    If InStr(Range("A" & Cells(Rows.Count, 1).End(xlUp).Row), "_PLB") = 0 Then Exit Sub

    colNumFact = Chr(64 + Range("NUMFACTURE").Column) ' A
    colClient = Chr(64 + Range("CLIENT").Column) ' B
    colObjet = Chr(64 + Range("OBJET").Column) ' C
    colDateFact = Chr(64 + Range("DateEmmissionFacture").Column) ' D
    coltotalHT = Chr(64 + Range("TOTALHT").Column)  ' E
    colTotalTTC = Chr(64 + Range("TOTALTTC").Column)  ' F
    colPaiementRecu = Chr(64 + Range("paiementrecule").Column) ' G
    colPaiementPar = Chr(64 + Range("PaiementPar").Column)
    colMainDoeuvre = Chr(64 + Range("MainDoeuvre").Column)
    colTVA = Chr(64 + Range("TVA").Column)
    colURSSAF = Chr(64 + Range("URSSAF").Column)
    colAutreFourniss = Chr(64 + Range("AUTRESFOURNISSEURS").Column)
    colWELDOM = Chr(64 + Range("WELDOM").Column)
    colBRICOLAGE = Chr(64 + Range("BRICOLAGE").Column)
    coltotalFournisseur = Chr(64 + Range("TOTALFOURNISSEURS").Column)
    colNetAttente = Chr(64 + Range("netenattente").Column)
    colNetGagne = Chr(64 + Range("netdejagagne").Column)
    
    Application.EnableEvents = False
    
    lignderfact = Cells(Rows.Count, 1).End(xlUp).Row
    ligneFinDeMois = lignderfact + 3
    Rows(ligneFinDeMois & ":" & ligneFinDeMois + 10).Insert
    Range(coltotalHT & "4:" & coltotalFournisseur & "5").Copy
    Range(coltotalHT & ligneFinDeMois).PasteSpecial
    
    Range(colPaiementRecu & ligneFinDeMois) = "jour"
    
    Range(colPaiementPar & ligneFinDeMois) = "ch�que, viremt"
    
    For i = 1 To 200
        If InStr(Range(colNumFact & ligneFinDeMois - i), "F_") <> 0 And _
        InStr(Range(colNumFact & ligneFinDeMois - i - 1), "F_") = 0 And (Range(colNumFact & ligneFinDeMois - i - 1) <> "") Then
            Range(colDateFact & ligneFinDeMois + 1) = Split(Range(colNumFact & ligneFinDeMois - i - 1), " ")(0) & Chr(10) & Split(Range(colNumFact & ligneFinDeMois - i - 1), " ")(1)
            With Range(colDateFact & ligneFinDeMois + 1)
                .Font.Italic = True
                .WrapText = True
                .Interior.ThemeColor = xlThemeColorDark1
                .Interior.TintAndShade = -0.149998474074526
                .Borders(xlEdgeBottom).LineStyle = True
                .Borders(xlEdgeTop).LineStyle = True
                .Borders(xlEdgeLeft).LineStyle = True
                .Borders(xlEdgeRight).LineStyle = True
            End With
            lignARecup = ligneFinDeMois - i
            Exit For
        End If
    Next
        
    Call ReInitFormules.calculFinDeMois
    
    Call ReInitFormules.RecalculMoisEnCours("non")
    
    Application.EnableEvents = True
    
    Call Init_ListBox3Et1
End Sub


Private Sub PlusUn_Click()
    colNumFact = Chr(64 + Range("NUMFACTURE").Column) ' A
    colClient = Chr(64 + Range("CLIENT").Column) ' B
    colObjet = Chr(64 + Range("OBJET").Column) ' C
    colDateFact = Chr(64 + Range("DateEmmissionFacture").Column) ' D
    coltotalHT = Chr(64 + Range("TOTALHT").Column)  ' E
    colTotalTTC = Chr(64 + Range("TOTALTTC").Column)  ' F
    colPaiement = Chr(64 + Range("paiementrecule").Column) ' G
    colPaiementPar = Chr(64 + Range("PaiementPar").Column)
    colMainDoeuvre = Chr(64 + Range("MainDoeuvre").Column)
    colTVA = Chr(64 + Range("TVA").Column)
    colURSSAF = Chr(64 + Range("URSSAF").Column)
    colAutreFourniss = Chr(64 + Range("AUTRESFOURNISSEURS").Column)
    colWELDOM = Chr(64 + Range("WELDOM").Column)
    colBRICOLAGE = Chr(64 + Range("BRICOLAGE").Column)
    coltotalFournisseur = Chr(64 + Range("TOTALFOURNISSEURS").Column)
    colNetTVA = Chr(64 + Range("NETSURTVA").Column)
    colNetAttente = Chr(64 + Range("netenattente").Column)
    colNetGagne = Chr(64 + Range("netdejagagne").Column)
    
    lignderfact = Cells(Rows.Count, 1).End(xlUp).Row

    If InStr(Range(colNumFact & lignderfact), "F_") = 0 And InStr(Range(colNumFact & lignderfact), "PLB") = 0 Then
        PremFactureDuMois = 1
        For i = 1 To 20
            If InStr(Range(colNumFact & lignderfact - i), "F_") <> 0 Then
                lignDerFactMoisDavant = lignderfact - i
                Exit For
            End If
        Next
    End If
    
    If PremFactureDuMois = 0 And (Range(colClient & lignderfact) = "" And _
    Range(colObjet & lignderfact) = "") Then Exit Sub
    Application.EnableEvents = False
    
    If PremFactureDuMois = 1 Then
    
        Rows(lignDerFactMoisDavant & ":" & lignDerFactMoisDavant + 2).Copy
        Rows(lignderfact + 1).Insert Shift:=xlDown
        Rows(lignderfact + 1).PasteSpecial Paste:=xlPasteFormats
        Range(colNumFact & lignderfact + 1).Hyperlinks.Delete
    
    ' gestion de l'incr�mentation ann�e et mois
        depPLB = "_" & Split(Range(colNumFact & lignDerFactMoisDavant), "_")(2) & "_" & Split(Range(colNumFact & lignDerFactMoisDavant), "_")(3)
        caseNumFacture = Split(Range(colNumFact & lignDerFactMoisDavant), "_")(1)
        Numfact = CDbl(Right(caseNumFacture, 3))
    
        depPLB = "_" & Split(Range(colNumFact & lignderfact + 1), "_")(2) & "_" & Split(Range("A" & lignderfact + 1), "_")(3)
        annee = Year(Range(colNumFact & lignderfact))
        Mois = Month(Range(colNumFact & lignderfact))
        If Len(Mois) = 1 Then Mois = "0" & Mois
        caseNumFacture = Split(Range(colNumFact & lignderfact + 1), "_")(1)
        
        caseNumFacture = annee & Mois & Right(caseNumFacture, 3)
        
        Range(colNumFact & lignderfact + 1) = "F_" & caseNumFacture

    ' gestion de l'incr�mentation du n� de facture
    
        Numfact = CDbl(Right(caseNumFacture, 3))
        If Len(Numfact) = 2 Then
            Range(colNumFact & lignderfact + 1) = Left(Range(colNumFact & lignderfact + 1), 8) & "0" & Numfact + 1
            Range(colNumFact & lignderfact + 1).Borders(xlEdgeTop).LineStyle = True
            Range(colNumFact & lignderfact + 1).Characters(Start:=10, Length:=2).Font.Color = vbRed
        Else:
            Range(colNumFact & lignderfact + 1) = Left(Range(colNumFact & lignderfact + 1), 8) & Numfact + 1
            Range(colNumFact & lignderfact + 1).Borders(xlEdgeTop).LineStyle = True
            Range(colNumFact & lignderfact + 1).Characters(Start:=9, Length:=3).Font.Color = vbRed
        End If
        
        Range(colNumFact & lignderfact + 1).Font.Bold = True
        Range(colClient & lignderfact + 1 & ":" & colClient & lignderfact + 2).ClearContents
        Range(colClient & lignderfact + 1).EntireRow.ClearComments
        Range(colObjet & lignderfact + 1).ClearContents
        Range(colDateFact & lignderfact + 1).ClearContents
        Range(colTotalTTC & lignderfact + 1).ClearContents
        Range(colMainDoeuvre & lignderfact + 1).ClearContents
        Range(colAutreFourniss & lignderfact + 3 & ":" & colBRICOLAGE & lignderfact + 3).ClearContents
        ActiveSheet.Calculate
        
    Else:
        For j = 1 To 100
            If Range("A" & lignderfact - j).Interior.ColorIndex <> xlNone And InStr(Range("A" & lignderfact - j), Year(Date)) <> 0 Then
                ligneCelluleMoisEnCours = lignderfact - j
                For i = 1 To 20
                    If InStr(Range(colNumFact & lignderfact - j - i), "_PLB") <> 0 Then
                        lignDerFactMoisDavant = lignderfact - j - i
                        Exit For
                    End If
                Next i
                Exit For
            End If
        Next j
        
        'trouver la ligne de facture qui n'a qu'une ligne, pas de .1 .2 .3
        
        Rows(lignderfact & ":" & lignderfact + 3).Copy
        Rows(lignderfact + 4 & ":" & lignderfact + 7).Insert
        Rows(lignderfact + 4).Borders(xlEdgeTop).LineStyle = True

        
'        Rows(lignderfact + 6).Borders(xlEdgeBottom).LineStyle = False
        Range(colNumFact & lignderfact + 3).Hyperlinks.Delete
        depPLB = "_" & Split(Range(colNumFact & lignderfact), "_")(2) & "_" & Split(Range(colNumFact & lignderfact), "_")(3)
        caseNumFacture = Split(Range(colNumFact & lignderfact), "_")(1)
        caseNumFacture = Mid(caseNumFacture, 1, 9)
        Application.CutCopyMode = False
        
        
        
        'si jamais le num�ro de mois de la facture d'avant n'est pas bien associ� au mois en question (pour cause de factures d�j� �dit�e et envoy�e avec le num�ro du mois d'avant) alors �a incr�mente de 1 pour retrouver le bon num�ro de mois dans le num de facture
        If CDbl(Mid(caseNumFacture, 5, 2)) <> Month(Range(colNumFact & lignderfact + 13)) Then
            depPLB = "_" & Split(Range(colNumFact & lignderfact), "_")(2) & "_" & Split(Range(colNumFact & lignderfact), "_")(3)
'            caseNumFacture = Split(Range(colNumFact & lignderfact), "_")(1)
'            Numfact = CDbl(Right(caseNumFacture, 3))
        
            depPLB = "_" & Split(Range(colNumFact & lignderfact), "_")(2) & "_" & Split(Range("A" & lignderfact), "_")(3)
            annee = Year(Range(colNumFact & ligneCelluleMoisEnCours))
            Mois = Month(Range(colNumFact & ligneCelluleMoisEnCours))
            If Len(Mois) = 1 Then Mois = "0" & Mois
'            caseNumFacture = Split(Range(colNumFact & lignderfact), "_")(1)
            
            caseNumFacture = annee & Mois & Right(caseNumFacture, 3)
            
            Range(colNumFact & lignderfact + 4) = "F_" & caseNumFacture
        End If
        Numfact = CDbl(Right(caseNumFacture, 3))
        
        If Len(Numfact) = 2 Then
            Range(colNumFact & lignderfact + 4) = Left(Range(colNumFact & lignderfact + 4), 8) & "0" & Numfact + 1
            Range(colNumFact & lignderfact + 4).Borders(xlEdgeTop).LineStyle = True
            Range(colNumFact & lignderfact + 4).Characters(Start:=10, Length:=2).Font.Color = vbRed
        Else:
            Range(colNumFact & lignderfact + 4) = Left(Range(colNumFact & lignderfact + 4), 8) & Numfact + 1
            Range(colNumFact & lignderfact + 4).Borders(xlEdgeTop).LineStyle = True
            Range(colNumFact & lignderfact + 4).Characters(Start:=9, Length:=3).Font.Color = vbRed
        End If
        
        Range(colNumFact & lignderfact + 4).Font.Bold = True
        Range(colClient & lignderfact + 4 & ":" & "B" & lignderfact + 4).ClearContents
        Range(colObjet & lignderfact + 4).ClearContents
        Range(colDateFact & lignderfact + 4).ClearContents
        Range(colTotalTTC & lignderfact + 4).ClearContents
        Range(colClient & lignderfact + 5).ClearContents
        Range(colMainDoeuvre & lignderfact + 4).ClearContents
        Range(colAutreFourniss & lignderfact + 4 & ":" & colBRICOLAGE & lignderfact + 4).ClearContents
        ActiveSheet.Calculate
        
    End If
    Application.EnableEvents = True
    
    
'    If PremFactureDuMois = 1 Then
'        typeclient = CHOISIR_CLIENT.ChoisirDossierTravailTableau1("", lignderfact + 1)
'        If typeclient <> "" Then _
'            Range(colClient & lignderfact + 1) = CHOISIR_CLIENT.ChoisirDossierTravailTableau1(typeclient, lignderfact + 1)
'    Else: typeclient = CHOISIR_CLIENT.ChoisirDossierTravailTableau1("", lignderfact + 4)
'        If typeclient <> "" Then _
'            Range(colClient & lignderfact + 4) = CHOISIR_CLIENT.ChoisirDossierTravailTableau1(typeclient, lignderfact + 4)
'    End If
    
    
    If PremFactureDuMois = 1 Then
'        typeclient = CHOISIR_CLIENT.ChoisirDossierTravailTableau("", lignderfact + 1)
'        If typeclient <> "" Then
            Range(colClient & lignderfact + 1) = CHOISIR_CLIENT.ChoisirDossierTravailTableau(typeclient, lignderfact + 1)
    Else: typeclient = CHOISIR_CLIENT.ChoisirDossierTravailTableau(typeclient, lignderfact + 4)
'        If typeclient <> "" Then
'            Range(colClient & lignderfact + 4) = CHOISIR_CLIENT.ChoisirDossierTravailTableau(typeclient, lignderfact + 4)
    End If

End Sub

    
Private Sub MoinsUn_Click()
    Dim chemin As String
    derlign = Cells(Rows.Count, 1).End(xlUp).Row
    
'la:
'    If Range("A" & derlign - 1) <> "" Then derlign = derlign - 1: GoTo la
    On Error GoTo MoinsUn
    client = Split(Range("A" & derlign), "_")(2)
    col = Chr(64 + Range("OBJET").Column)
    Locataire = Range("B" & derlign + 1)
    
    If Range(col & derlign) <> "" Then Exit Sub ' s�curit� !! �a signifie que s'il y a un objet la ligne ne sera pas supprim�e
    
    
    If client = "DEP" And Locataire <> "" Then
        Locataire = Range("B" & derlign + 1)
        ' Construit le chemin complet : dossier + nom de fichier (pris en A1)
        nomImmo = Range("B" & derlign)
        chemin = Environ("USERPROFILE") & "\Documents\(00) - TRAVAIL\00 - BATIMENT\01-OB PLOMBERIE\00 - FACTURES-DEVIS\2026\0 - AGENCES IMMO\" & nomImmo & "\FACTURES\"
'        MsgBox chemin
        fichier = Dir(chemin & "*.xlsm")
        fichier = Dir() '�a permet de commencer la recherche qu'au 2e fichier, vu que le 1er c'est le fichier mod�le
        If Dir(chemin) <> "" Then
            Do While chemin <> ""
                If InStr(Split(fichier, "-FACT-")(1), Locataire) > 0 Then Exit Do
                fichier = Dir
            Loop
        Else:
            MsgBox "Fichier non-trouv� mais la ligne sera supprim�e du tableau!"
            GoTo MoinsUn
        End If
        
        chemindufichier = chemin & fichier
'         V�rifie si le fichier existe
        If Dir(chemin) <> "" Then
            If MsgBox("Voulez-vous vraiment supprimer le fichier ?" & vbCrLf & fichier, _
                      vbYesNo + vbQuestion, "Confirmation de suppression") = vbYes Then
                
killDEP:
                On Error Resume Next
             ' Supprime le fichier
                Kill chemindufichier
                If Err.Number <> 0 Then
                    Workbooks(fichier).Close SaveChanges:=False
                    MsgBox ("Fichier [" & fichier & "] ferm� automatiquement (sans sauvegarde).")
                    Err.Clear
                    On Error GoTo 0
                    GoTo killDEP
                End If
                MsgBox ("Fichier [" & fichier & "] supprim�!")
            Else:
                Exit Sub
            End If
        End If


    ElseIf client = "ST" Then
    ' Construit le chemin complet : dossier + nom de fichier (pris en A1)
        nomST = Range("B" & derlign)
    ' Construit le chemin complet : dossier + nom de fichier (pris en A1)
        chemin = "C:\Users\olivi\Documents\(00) - TRAVAIL\00 - BATIMENT\01-OB PLOMBERIE\00 - FACTURES-DEVIS\2026\1 - SOUS-TRAITANCE\" & nomST & "\FACTURES\"
        fichier = Dir(chemin & "*.xlsm")
'        MsgBox fichier
        If Dir(chemin) <> "" Then
            Do While chemin <> ""
                If InStr(fichier, Split(nomST, " ")(0)) > 0 Then Exit Do
                fichier = Dir
            Loop
        Else:
            MsgBox "Fichier non-trouv� mais la ligne sera supprim�e du tableau!"
            GoTo MoinsUn
        End If
        
        chemindufichier = chemin & fichier
        ' V�rifie si le fichier existe
        If Dir(chemindufichier) <> "" Then
            If MsgBox("Voulez-vous vraiment supprimer le fichier ?" & vbCrLf & chemindufichier, _
                      vbYesNo + vbQuestion, "Confirmation de suppression") = vbYes Then
killST:
                On Error Resume Next
            ' Supprime le fichier
                Kill chemindufichier
                If Err.Number <> 0 Then
                    Workbooks(fichier).Close SaveChanges:=False
                    MsgBox ("Fichier [" & fichier & "] ferm� automatiquement (sans sauvegarde).")
                    Err.Clear
                    On Error GoTo 0
                    GoTo killST
                End If
                MsgBox ("Fichier [" & fichier & "] supprim�!")
            End If
        End If
        
    ElseIf client = "CLI" Then
        nomclient = Range("B" & derlign)
    ' Construit le chemin complet : dossier + nom de fichier (pris en A1)
        chemin = "C:\Users\olivi\Documents\(00) - TRAVAIL\00 - BATIMENT\01-OB PLOMBERIE\00 - FACTURES-DEVIS\2026\2 - CLIENTS DIRECTS\" & nomclient & "\FACTURES\"
        fichier = Dir(chemin & "*.xlsm")
'        MsgBox fichier
        If Dir(chemin) <> "" Then
            Do While chemin <> ""
                If InStr(fichier, Split(nomclient, " ")(0)) > 0 Then Exit Do
                fichier = Dir
            Loop
        Else:
            MsgBox "Fichier non-trouv� mais la ligne sera supprim�e du tableau!"
            GoTo MoinsUn
        End If
        
        chemindufichier = chemin & fichier
        ' V�rifie si le fichier existe
        If Dir(chemindufichier) <> "" Then
            If MsgBox("Voulez-vous vraiment supprimer le fichier ?" & vbCrLf & chemindufichier, _
                      vbYesNo + vbQuestion, "Confirmation de suppression") = vbYes Then
killCLI:
                On Error Resume Next
             ' Supprime le fichier
                Kill chemindufichier
                If Err.Number <> 0 Then
                    Workbooks(fichier).Close SaveChanges:=False
                    MsgBox ("Fichier [" & fichier & "] ferm� automatiquement (sans sauvegarde).")
                    Err.Clear
                    On Error GoTo 0
                    GoTo killCLI
                End If
                MsgBox ("Fichier [" & fichier & "] supprim�!")
            End If
        End If
    End If
    
MoinsUn:
    Call MOINS_UN.MOINS_UN
End Sub


Private Sub SousTraitance_Click()
    shell "explorer.exe """ & "C:\Users\olivi\Documents\(00) - TRAVAIL\00 - BATIMENT\01-OB PLOMBERIE\00 - FACTURES-DEVIS\2025\1 - SOUS-TRAITANCE" & """", vbNormalFocus
End Sub














Private Function GetDossierParent() As String
    GetDossierParent = Environ("USERPROFILE") & "\Documents\(00) - TRAVAIL\00 - BATIMENT\01-OB PLOMBERIE\00 - FACTURES-DEVIS\2026\"
End Function


Private Sub CommandButton1_Click()
    Dim fso As Object, dossier As Object, sousDossier As Object
    Dim CheminDossier As String
    
    CheminDossier = GetDossierParent() & "0 - AGENCES IMMO"
    Me.ListBox2.Clear
    
    ' AJOUT DU NOM DU BOUTON EN 1ER
    Me.ListBox2.AddItem "=== AGENCES IMMOBILI�RES ==="
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(CheminDossier) Then
        Set dossier = fso.GetFolder(CheminDossier)
        For Each sousDossier In dossier.SubFolders
            Me.ListBox2.AddItem sousDossier.Name
        Next sousDossier
    Else
        MsgBox "Dossier non trouv� : " & CheminDossier
    End If
    Set fso = Nothing
End Sub

Private Sub CommandButton2_Click()
    Dim fso As Object, dossier As Object, sousDossier As Object
    Dim CheminDossier As String
    
    CheminDossier = GetDossierParent() & "1 - SOUS-TRAITANCE"
    Me.ListBox2.Clear
    
    ' AJOUT DU NOM DU BOUTON EN 1ER
    Me.ListBox2.AddItem "=== SOUS-TRAITANCE ==="
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(CheminDossier) Then
        Set dossier = fso.GetFolder(CheminDossier)
        For Each sousDossier In dossier.SubFolders
            Me.ListBox2.AddItem sousDossier.Name
        Next sousDossier
    Else
        MsgBox "Dossier non trouv� : " & CheminDossier
    End If
    Set fso = Nothing
End Sub

Private Sub CommandButton3_Click()
    Dim fso As Object, dossier As Object, sousDossier As Object
    Dim CheminDossier As String
    
    CheminDossier = GetDossierParent() & "2 - CLIENTS DIRECTS\"
    Me.ListBox2.Clear
    
    ' AJOUT DU NOM DU BOUTON EN 1ER
    Me.ListBox2.AddItem "=== CLIENTS DIRECTS ==="
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(CheminDossier) Then
        Set dossier = fso.GetFolder(CheminDossier)
        For Each sousDossier In dossier.SubFolders
            Me.ListBox2.AddItem sousDossier.Name
        Next sousDossier
    Else
        MsgBox "Dossier non trouv� : " & CheminDossier
    End If
    Set fso = Nothing
End Sub


Private Sub ListBox2_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    Dim NomSousDossier As String, CheminFactures As String
    Dim dossierRacine As String
    
    If Me.ListBox2.ListIndex = 0 Then
        If InStr(1, Me.ListBox2.List(0), "AGENCES") > 0 Then
            dossierRacine = GetDossierParent() & "0 - AGENCES IMMO\"
            chemin = dossierRacine
        ElseIf InStr(1, Me.ListBox2.List(0), "SOUS-TRAITANCE") > 0 Then
            dossierRacine = GetDossierParent() & "1 - SOUS-TRAITANCE\"
            chemin = dossierRacine
        Else
            dossierRacine = GetDossierParent() & "2 - CLIENTS DIRECTS\"
            chemin = dossierRacine
        End If
        shell "explorer.exe """ & chemin & """", vbNormalFocus
    ElseIf Me.ListBox2.ListIndex >= 0 Then  ' > 0 = ignore le 1er �l�ment (titre)
        NomSousDossier = Me.ListBox2.Value
        
        ' D�tecte le dossier via le 1er �l�ment (titre)
        If InStr(1, Me.ListBox2.List(0), "AGENCES") > 0 Then
            dossierRacine = GetDossierParent() & "0 - AGENCES IMMO\"
            CheminFactures = dossierRacine & NomSousDossier & "\FACTURES"
        ElseIf InStr(1, Me.ListBox2.List(0), "SOUS-TRAITANCE") > 0 Then
            dossierRacine = GetDossierParent() & "1 - SOUS-TRAITANCE\"
            CheminFactures = dossierRacine & NomSousDossier & "\FACTURES"
        Else
            dossierRacine = GetDossierParent() & "2 - CLIENTS DIRECTS\"
            CheminFactures = dossierRacine & NomSousDossier
        End If
        
        If Dir(CheminFactures, vbDirectory) <> "" Then
            shell "explorer.exe """ & CheminFactures & """", vbNormalFocus
        Else
            MsgBox "Dossier FACTURES non trouv� : " & CheminFactures
        End If
    End If
End Sub



      
Private Sub sauvegarde_Click()
    ActiveWorkbook.Save
End Sub

Private Sub userform_activate()
    ' Position HAUT-GAUCHE qui FONCTIONNE � 100%
    Me.Left = 10
    Me.Top = 10

End Sub

Private Sub UserForm_Initialize()
    
    Call Init_ListBox3Et1
    
End Sub



'    For Each cell In rng
'        If cell.Value <> "" Then
'            ValeurCellule = LCase(cell.Value)
'            If Len(ValeurCellule) > 6 And IsNumeric(Right(ValeurCellule, 4)) Then
'
'                ' NOUVELLE ANN�E ? ligne vide SEULEMENT apr�s la premi�re
'                If Right(ValeurCellule, 4) <> currentAnnee Then
'                    If Not premiereAnnee Then
'                        Me.ListBox1.AddItem ""  ' ? Ligne vide (sauf premi�re ann�e)
'                    End If
'                    Me.ListBox1.AddItem "---- " & Right(cell.Value, 4) & " ----"
'                    currentAnnee = Right(ValeurCellule, 4)
'                    premiereAnnee = False
'                End If
'
''                ' Ajoute le mois
'                Dim idx As Integer
'                lignB = cell.Address
'                idx = Me.ListBox1.ListCount
'                Me.ListBox1.AddItem cell.Value
'                Me.ListBox3.List(0) = cell.Value
'                lignH = cell.Value
'
'                Me.ListBox1.List(idx, 1) = cell.Address
'            End If
'        End If
'    Next cell

Private Sub Init_ListBox3Et1()
    Dim ws As Worksheet, rng As Range, cell As Range, cellCheck As Range
    Dim DerniereLigne As Long, ValeurCellule As String, currentAnnee As String
    Dim premiereAnnee As Boolean, idx As Integer, idx3 As Integer, moisKey As String
    Dim colPaiement As Integer, colNetEnAttente As Integer
    Dim dictSomme As Object, sommeMois As Double
    Dim fichierAjoute As Boolean
    
    Set ws = ActiveSheet
    Me.ListBox1.Clear
    Me.ListBox1.ColumnCount = 2
    Me.ListBox1.ColumnWidths = "90,90"
    
    Me.ListBox3.ColumnCount = 2
    Me.ListBox3.ColumnWidths = "90,90"
    Me.ListBox3.Clear
    
    ' Headers ListBox3
    Me.ListBox3.AddItem "MOIS"
    Me.ListBox3.List(0, 1) = "NET EN ATTENTE"
    Me.ListBox3.AddItem ""
    Me.ListBox3.List(1, 1) = ""
    
    DerniereLigne = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row
    Set rng = ws.Range("A6:A" & DerniereLigne)
    
    currentAnnee = Format(Date, "yyyy")  ' 2026
    colPaiement = ws.Range("paiementrecule").Column
    colNetEnAttente = ws.Range("netenattente").Column
    Set dictSomme = CreateObject("Scripting.Dictionary")
    
    ' 1�RE PASSE : Calcul sommes PLB
    Dim moisHeader As String
    For Each cellCheck In rng
        If Len(cellCheck.Value) > 6 And IsNumeric(Right(LCase(cellCheck.Value), 4)) Then
            moisHeader = Trim(cellCheck.Value)
        End If
        
        If Right(cellCheck.Value, 4) = "_PLB" Then
            If IsEmpty(ws.Cells(cellCheck.Row, colPaiement)) Then
                If dictSomme.Exists(moisHeader) Then
                    dictSomme(moisHeader) = dictSomme(moisHeader) + ws.Cells(cellCheck.Row, colNetEnAttente).Value
                Else
                    dictSomme(moisHeader) = ws.Cells(cellCheck.Row, colNetEnAttente).Value
                End If
            End If
        End If
    Next cellCheck
    
    ' 2�ME PASSE : Affichage + 1 ligne fichier PAR ANN�E
   premiereAnnee = True
    fichierAjoute = False
    For Each cell In rng
        If Len(cell.Value) > 6 And IsNumeric(Right(LCase(cell.Value), 4)) Then
            ValeurCellule = LCase(cell.Value)
            moisKey = Trim(cell.Value)
            
            ' NOUVELLE ANN�E
            If Right(ValeurCellule, 4) <> currentAnnee Then
                If Not premiereAnnee Then Me.ListBox1.AddItem ""
                
                Me.ListBox1.AddItem "---- " & Right(cell.Value, 4) & " ----"
                idx = Me.ListBox1.ListCount - 1
                Me.ListBox1.List(idx, 1) = "NET EN ATTENTE"
                
                ' ? UNE SEULE LIGNE "OUVRIR FICHIER" PAR ANN�E (PAS 2026)
                If Right(cell.Value, 4) <> Format(Date, "yyyy") Then
                    Me.ListBox1.AddItem "OUVRIR FICHIER " & Right(cell.Value, 4)
                End If
                
                currentAnnee = Right(ValeurCellule, 4)
                premiereAnnee = False
                fichierAjoute = True
            End If
            
            ' Affichage mois (SAUF si d�j� fichier ajout� pour cette ann�e)
            If Not fichierAjoute Or Right(moisKey, 4) = Format(Date, "yyyy") Then
                idx = Me.ListBox1.ListCount
                Me.ListBox1.AddItem moisKey
                
                If Right(moisKey, 4) = Format(Date, "yyyy") Then
                    ' Ann�e en cours : somme
                    If dictSomme.Exists(moisKey) Then
                        sommeMois = dictSomme(moisKey)
                        If sommeMois > 0 Then
                            Me.ListBox1.List(idx, 1) = Format(sommeMois, "#,##0.00") & " �"
                            idx3 = Me.ListBox3.ListCount
                            Me.ListBox3.AddItem moisKey
                            Me.ListBox3.List(idx3, 1) = Format(sommeMois, "#,##0.00") & " �"
                        Else
                            Me.ListBox1.List(idx, 1) = ""
                        End If
                    Else
                        Me.ListBox1.List(idx, 1) = ""
                    End If
                End If
            End If
        End If
    Next cell
End Sub



Private Sub ListBox1_Click()
    Dim ws As Worksheet
    Dim NomMois As String
    Dim CelluleTrouvee As Range
    Index = Me.ListBox1.ListIndex
    Debug.Print "-" & Right(Me.ListBox1.List(Index, 0), 4) & "-"
    
    chemin = recupCheminnNomEntreprise
    chemin = chemin & "\99 - EXCELS\" & _
        Right(Me.ListBox1.List(Index, 0), 4) & "\" & Right(Me.ListBox1.List(Index, 0), 4) & " - FACTURES DEVIS.xlsm"
    If InStr(Me.ListBox1.List(Index, 0), "OUVRIR") <> 0 Then Workbooks.Open chemin
    
    If Me.ListBox1.ListIndex > 0 Then
        NomMois = Me.ListBox1.Value
        
        ' IGNORER les s�parateurs d'ann�es
        If Left(NomMois, 5) <> "=====" Then
            Set ws = ActiveSheet
            
            Set CelluleTrouvee = ws.Range("A:A").Find(What:=NomMois, LookIn:=xlValues, LookAt:=xlWhole)
            
            If Not CelluleTrouvee Is Nothing Then
                CelluleTrouvee.Select
                Me.ListBox1.ListIndex = -1
            Else
                MsgBox "Mois '" & NomMois & "' non trouv�"
            End If
        End If
    End If
    
    Call Init_ListBox3Et1
End Sub

Private Sub ListBox3_Click()
    Dim ws As Worksheet
    Dim NomMois As String
    Dim CelluleTrouvee As Range
    Index = Me.ListBox3.ListIndex
    
    If Me.ListBox3.ListIndex >= 0 Then
        NomMois = Me.ListBox3.Value
        
        ' IGNORER les s�parateurs d'ann�es
'        If Left(NomMois, 5) <> "=====" Then
            Set ws = ActiveSheet
            
            Set CelluleTrouvee = ws.Range("A:A").Find(What:=NomMois, LookIn:=xlValues, LookAt:=xlWhole)
            
            If Not CelluleTrouvee Is Nothing Then
                CelluleTrouvee.Select
                Me.ListBox3.ListIndex = -1
            Else
                MsgBox "Mois '" & NomMois & "' non trouv�"
            End If
'        End If
    End If
    
    Call Init_ListBox3Et1
End Sub
