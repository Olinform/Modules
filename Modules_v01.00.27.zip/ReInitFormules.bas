Attribute VB_Name = "ReInitFormules"


Sub calculFinDeMois()
    coltotalHT = Chr(64 + Range("TOTALHT").Column)
    colTotalTTC = Chr(64 + Range("TOTALTTC").Column)  ' Nouvelle plage nomm�e
    colTVA = Chr(64 + Range("TVA").Column)
    colURSSAF = Chr(64 + Range("URSSAF").Column)
    colAutreFourniss = Chr(64 + Range("AUTRESFOURNISSEURS").Column)
    colWELDOM = Chr(64 + Range("WELDOM").Column)
    colBRICOLAGE = Chr(64 + Range("BRICOLAGE").Column)
    colTotalFourniss = Chr(64 + Range("TOTALFOURNISSEURS").Column)
    colNetTVA = Chr(64 + Range("NETSURTVA").Column)
    colNetAttente = Chr(64 + Range("netenattente").Column)
    colNetGagne = Chr(64 + Range("netdejagagne").Column)
    colPaiementRecu = Chr(64 + Range("paiementrecule").Column)
    colDateFact = Chr(64 + Range("DateEmmissionFacture").Column)
    colNumFact = Chr(64 + Range("NUMFACTURE").Column)

    lignderfact = Cells(Rows.Count, 1).End(xlUp).Row
    If InStr(Range("A" & lignderfact), "F_20") = 0 Then lignderfact = Cells(Rows.Count, 1).End(xlUp).Row - 13
    ligneFinDeMois = lignderfact + 3
    
    If SEULouPOURMACRO = "SEUL" Then
        For i = 1 To 50000
            If InStr(Range("A" & ligneFinDeMois - i), "F_") <> 0 And Range("A" & ligneFinDeMois - i - 1) <> "" Then
                dMois = DateValue("1 " & Date) ' -> 01/01/2025
                dDeb = DateSerial(Year(dMois), Month(dMois), 1)
                dFin = DateSerial(Year(dMois), Month(dMois) + 1, 0)
                lignARecup = ligneFinDeMois - i
                Exit For
            End If
         Next
    Else:
        For i = 1 To 50000
            If InStr(Range(colNumFact & ligneFinDeMois - i), "F_") <> 0 And _
            InStr(Range(colNumFact & ligneFinDeMois - i - 1), "F_") = 0 And (Range(colNumFact & ligneFinDeMois - i - 1) <> "") Then
                lignARecup = ligneFinDeMois - i
                Exit For
            End If
        Next
        dMois = DateValue("1 " & Range("A" & lignARecup - 1).Value) ' -> 01/01/2025
        dDeb = DateSerial(Year(dMois), Month(dMois), 1)
        dFin = DateSerial(Year(dMois), Month(dMois) + 1, 0)
    End If
    
    ' POUR MOIS QUI SE TERMINE
'Montant total HT
    Range(coltotalHT & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & coltotalHT & "8:" & coltotalHT & ligneFinDeMois - 1 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois - 1 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<>""" & ")"

'Montant total TTC
    Range(colTotalTTC & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colTotalTTC & "8:" & colTotalTTC & ligneFinDeMois - 1 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois - 1 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<>""" & ")"

'TVA
    Range(colTVA & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colTVA & "8:" & colTVA & ligneFinDeMois - 1 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois - 1 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<>""" & ")"

'URSSAF
    Range(colURSSAF & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colURSSAF & "8:" & colURSSAF & ligneFinDeMois - 1 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois - 1 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<>""" & ")"

'Pr�l�vements AUTRES FOURNISSEURS
    Range(colAutreFourniss & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colAutreFourniss & lignARecup & ":" & colAutreFourniss & ligneFinDeMois - 1 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois - 1 & _
    ";""<>""" & ")"
    
'Pr�l�vements WELDOM
    Range(colWELDOM & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colWELDOM & lignARecup & ":" & colWELDOM & ligneFinDeMois - 1 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois - 1 & _
    ";""<>""" & ")"

'Pr�l�vements MR BRICOLAGE
    Range(colBRICOLAGE & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colBRICOLAGE & lignARecup & ":" & colBRICOLAGE & ligneFinDeMois - 1 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois - 1 & _
    ";""<>""" & ")"
    
' TOTAL FOURNISSEURS
    Range(colTotalFourniss & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colTotalFourniss & lignARecup & ":" & colTotalFourniss & ligneFinDeMois - 1 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois - 1 & _
    ";""<>""" & ")"

'Net sur TVA
    Range(colNetTVA & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colNetTVA & "8:" & colNetTVA & ligneFinDeMois - 1 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois - 1 & _
    ";""<>""" & ")"

'Net d�j� gagn�
    Range(colNetAttente & ligneFinDeMois).FormulaLocal = _
    "=SOMME.SI.ENS(" & colNetAttente & "8:" & colNetAttente & ligneFinDeMois - 1 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois - 1 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois - 1 & _
    ";""<>""" & ")"
    
    With Range(colNetAttente & ligneFinDeMois)
        .Interior.PatternColorIndex = xlAutomatic
        .Interior.ThemeColor = xlThemeColorAccent3
        .Interior.TintAndShade = 0.399975585192419
        .Borders(xlEdgeLeft).LineStyle = True
        .Borders(xlEdgeRight).LineStyle = True
        .Borders(xlEdgeTop).LineStyle = True
        .Borders(xlEdgeBottom).LineStyle = True
        .Font.ThemeColor = xlThemeColorAccent3
        .Font.TintAndShade = -0.499984740745262
        .NumberFormat = "# ##0.00 �"
    End With
    
    Range(colNetAttente & ligneFinDeMois + 1) = "net"
    With Range(colNetAttente & ligneFinDeMois + 1)
        .Borders(xlEdgeLeft).LineStyle = True
        .Borders(xlEdgeRight).LineStyle = True
        .Borders(xlEdgeTop).LineStyle = True
        .Borders(xlEdgeBottom).LineStyle = True
    End With
    With Range(colNetAttente & ligneFinDeMois + 1).Interior
        .Pattern = xlSolid
        .PatternColorIndex = xlAutomatic
        .ThemeColor = xlThemeColorDark2
        .TintAndShade = 0
        .PatternTintAndShade = 0
    End With
    With Range(colNetAttente & ligneFinDeMois + 1)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    Range(colNetAttente & ligneFinDeMois + 1).Font.Bold = True
 
    Range(colTotalFourniss & ligneFinDeMois & ":" & colTotalFourniss & ligneFinDeMois + 1).Copy
    Range(colNetTVA & ligneFinDeMois).PasteSpecial xlPasteFormats
    Range(colNetTVA & ligneFinDeMois + 1) = "Net sur TVA"
    Range(colNetTVA & ligneFinDeMois + 1).WrapText = True
    Range(colNetTVA & ligneFinDeMois + 1).Font.Size = 11
    
    Range(colNetAttente & ligneFinDeMois + 4) = "net final"
    Range(colNetAttente & ligneFinDeMois + 1).Copy
    Range(colNetAttente & ligneFinDeMois + 2).PasteSpecial Paste:=xlPasteFormats
    Range(colNetAttente & ligneFinDeMois + 2) = "D�penses moi"
    Range(colNetAttente & ligneFinDeMois + 2).Font.Bold = True
    Range(colNetAttente & ligneFinDeMois + 1).Copy
    Range(colNetAttente & ligneFinDeMois + 4).PasteSpecial Paste:=xlPasteFormats
    Range(colNetAttente & ligneFinDeMois).Copy
    Range(colNetAttente & ligneFinDeMois + 5).FormulaLocal = _
        "=" & colNetAttente & ligneFinDeMois & "-" & colNetAttente & (ligneFinDeMois + 3)

    Range(colNetAttente & ligneFinDeMois + 5).PasteSpecial Paste:=xlPasteFormats
    Range(colNetAttente & ligneFinDeMois + 5).Font.Bold = True

    With Range(colNetAttente & ligneFinDeMois + 3)
        .Interior.PatternColorIndex = xlAutomatic
        .Interior.ThemeColor = xlThemeColorAccent6
        .Interior.TintAndShade = 0.599993896298105
        .Borders(xlEdgeLeft).LineStyle = True
        .Borders(xlEdgeRight).LineStyle = True
        .Borders(xlEdgeTop).LineStyle = True
        .Borders(xlEdgeBottom).LineStyle = True
        .Font.Color = -16777024
        .Font.TintAndShade = 0
    End With
    
    d = DateValue("1 " & Range(colNumFact & lignARecup - 1).Value)
    
    Range(colNumFact & ligneFinDeMois + 10).Value = Format(DateAdd("m", 1, d), "mmmm yyyy")
    Range(colNumFact & ligneFinDeMois + 10).Font.Italic = True
    With Range(colNumFact & ligneFinDeMois + 10)
        .Interior.PatternColorIndex = xlAutomatic
        .Interior.ThemeColor = xlThemeColorDark1
        .Interior.TintAndShade = -0.249977111117893
        .Borders(xlEdgeLeft).LineStyle = True
        .Borders(xlEdgeRight).LineStyle = True
        .Borders(xlEdgeTop).LineStyle = True
        .Borders(xlEdgeBottom).LineStyle = True
    End With
    
    Range(coltotalHT & 2).Formula = Range(coltotalHT & 2).Formula & " + " & coltotalHT & ligneFinDeMois
    
    ' compter le nombre de DEP ST ou CLI
    nbdep = 0
    nbst = 0
    nbcli = 0
    nbFact = 0
    For i = lignARecup To ligneFinDeMois
        If InStr(Range("A" & i), "_DEP_") <> 0 Then
            nbdep = nbdep + 1
            nbFact = nbFact + 1
        ElseIf InStr(Range("A" & i), "_ST_") <> 0 Then
            nbst = nbst + 1
            nbFact = nbFact + 1
        ElseIf InStr(Range("A" & i), "_CLI_") <> 0 Then
            nbcli = nbcli + 1
            nbFact = nbFact + 1
        End If
    Next i
    
    Range("B" & lignARecup - 1) = nbFact & " facture(s)"
    
    Range(colDateFact & ligneFinDeMois + 2) = nbFact & " factures"
    Range(colDateFact & ligneFinDeMois + 3) = nbdep & " d�pannages"
    Range(colDateFact & ligneFinDeMois + 4) = nbst & " sous-traitances"
    Range(colDateFact & ligneFinDeMois + 5) = nbcli & " clients directs"
    Range(colDateFact & ligneFinDeMois + 3 & ":" & colDateFact & ligneFinDeMois + 5).Font.Size = 10

    Range("B" & ligneFinDeMois + 10).FormulaLocal = "=NB.SI(" & Chr(64 + 1) & ligneFinDeMois + 10 & ":" & _
    "INDEX(" & Chr(64 + 1) & ":" & Chr(64 + 1) & ";LIGNES(" & Chr(64 + 1) & ":" & Chr(64 + 1) & ")-SOMME(--ESTVIDE(" & _
    Chr(64 + 1) & ":" & Chr(64 + 1) & ")));" & """F_*"")"
    Range("B" & ligneFinDeMois + 10).HorizontalAlignment = xlLeft
    Range("B" & ligneFinDeMois + 10).Font.Italic = True
    Range("B" & ligneFinDeMois + 10).Font.Size = 10
    Range("B" & ligneFinDeMois + 10).NumberFormat = "0"" facture(s)"""

End Sub 'calculFinDeMois









Sub RecalculMoisEnCours(pourSuppressionOUINON)
    coltotalHT = Chr(64 + Range("TOTALHT").Column)
    colTotalTTC = Chr(64 + Range("TOTALTTC").Column)
    colTVA = Chr(64 + Range("TVA").Column)
    colURSSAF = Chr(64 + Range("URSSAF").Column)
    colAutreFourniss = Chr(64 + Range("AUTRESFOURNISSEURS").Column)
    colWELDOM = Chr(64 + Range("WELDOM").Column)
    colBRICOLAGE = Chr(64 + Range("BRICOLAGE").Column)
    colTotalFourniss = Chr(64 + Range("TOTALFOURNISSEURS").Column)
    colNetTVA = Chr(64 + Range("NETSURTVA").Column)
    colNetAttente = Chr(64 + Range("netenattente").Column)
    colNetGagne = Chr(64 + Range("netdejagagne").Column)
    colPaiementRecu = Chr(64 + Range("paiementrecule").Column)
    colDateFact = Chr(64 + Range("DateEmmissionFacture").Column)
    colNumFact = Chr(64 + Range("NUMFACTURE").Column)

    lignderfact = Cells(Rows.Count, 1).End(xlUp).Row
    If pourSuppressionOUINON = "oui" Then
        ligneFinDeMois = lignderfact + 4
    Else: ligneFinDeMois = lignderfact + 1
    End If
    
    p = 0
    For i = 0 To 100 Step 4
        If InStr(Range("A" & lignderfact - i), "F_20") = 0 And Range("A" & lignderfact - i) <> "" Then Exit For
        If InStr(Range("A" & lignderfact - i), "F_20") <> 0 Then p = p + 1
        If Range("A" & lignderfact - i - 1) <> "" Then Exit For
    Next i
    
    If p = 0 Then lignARecup = lignderfact + 1 Else: lignARecup = lignderfact - ((p - 1) * 4)
'    If pourSuppressionOUINON = "oui" Then
    If InStr(Range("A" & lignARecup - 1), "F_20") = 0 Then
        dMois = DateValue("1 " & Range("A" & lignARecup - 1)) ' -> 01/01/2025
    Else:
        dMois = DateValue("1 " & Month(Date))
    End If
'    End If
    
    dDeb = DateSerial(Year(dMois), Month(dMois), 1)
    dFin = DateSerial(Year(dMois), Month(dMois) + 1, 0)
    
    Application.EnableEvents = False
    
    tableau = Split(Range(coltotalHT & 2).Formula, "+")
    tableau(0) = Split(Replace(Range(coltotalHT & 2).Formula, "=", ""), "+")(1)
    formule = "="
    
    If pourSuppressionOUINON = "oui" Then
        For i = 0 To UBound(tableau) - 1
            formule = formule & tableau(i) & "+"
        Next i
        Range(coltotalHT & 2).Formula = Left(formule, Len(formule) - 1)
    End If
    
    Range(colWELDOM & ligneFinDeMois).NumberFormat = "0.00"
    Range(colWELDOM & "1") = MonthName(Month(dMois))
    
    'MOIS QUI DEBUTE
'Montant total HT
    Range(coltotalHT & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & coltotalHT & "8:" & coltotalHT & ligneFinDeMois + 20 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois + 20 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'Montant total TTC
    Range(colTotalTTC & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colTotalTTC & "8:" & colTotalTTC & ligneFinDeMois + 20 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois + 20 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'TVA
    Range(colTVA & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colTVA & "8:" & colTVA & ligneFinDeMois + 20 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois + 20 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'URSSAF
    Range(colURSSAF & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colURSSAF & "8:" & colURSSAF & ligneFinDeMois + 20 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois + 20 & _
    ";""*F_20*""" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'Pr�l�vements AUTRES FOURNISSEURS
    Range(colAutreFourniss & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colAutreFourniss & lignARecup & ":" & colAutreFourniss & ligneFinDeMois + 20 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'Pr�l�vements WELDOM
    Range(colWELDOM & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colWELDOM & lignARecup & ":" & colWELDOM & ligneFinDeMois + 20 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'Pr�l�vements MR BRICOLAGE
    Range(colBRICOLAGE & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colBRICOLAGE & lignARecup & ":" & colBRICOLAGE & ligneFinDeMois + 20 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois + 20 & _
    ";""<>""" & ")"
    
' TOTAL FOURNISSEURS
    Range(colTotalFourniss & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colTotalFourniss & lignARecup & ":" & colTotalFourniss & ligneFinDeMois + 20 & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colDateFact & lignARecup & ":" & colDateFact & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & lignARecup & ":" & colNumFact & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'Net sur TVA
'    Range(colNetTVA & ligneFinDeMois).NumberFormat = "0.00"

'    Range(colNetTVA & "4").FormulaLocal = _
'    "=SOMME.SI.ENS(" & colNetTVA & "8:" & colNetTVA & ligneFinDeMois + 20 & _
'    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
'    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
'    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
'    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
'    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois + 20 & _
'    ";""<>""" & ")"

'    Range(colNetAttente & ligneFinDeMois).NumberFormat = "0.00"

'Net d�j� gagn�
    Range(colNetGagne & "4").FormulaLocal = _
    "=SOMME.SI.ENS(" & colNetAttente & "8:" & colNetAttente & ligneFinDeMois + 20 & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";"">=" & Format(dDeb, "dd/mm/yyyy") & """" & _
    ";" & colPaiementRecu & "8:" & colPaiementRecu & ligneFinDeMois + 20 & _
    ";""<=" & Format(dFin, "dd/mm/yyyy") & """" & _
    ";" & colNumFact & "8:" & colNumFact & ligneFinDeMois + 20 & _
    ";""<>""" & ")"

'    Range("B" & lignARecup - 1).FormulaLocal = "=NB.SI(" & Chr(64 + 1) & lignARecup - 1 & ":" & _
'    "INDEX(" & Chr(64 + 1) & ":" & Chr(64 + 1) & ";LIGNE(INDIRECT(" & Chr(64 + 1) & Chr(64 + 1) & _
'    "&NBVAL(" & Chr(64 + 1) & ":" & Chr(64 + 1) & "))))" & ";" & """F_*""" & ")"
    
    Application.EnableEvents = True
    
    Range("A" & Cells(Rows.Count, 1).End(xlUp).Row).Select
    
End Sub 'RecalculMoisEnCours
