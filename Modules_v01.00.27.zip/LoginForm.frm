VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} LoginForm 
   Caption         =   "AUTHENTIFICATION REQUISE"
   ClientHeight    =   2415
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   5760
   OleObjectBlob   =   "LoginForm.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "LoginForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub btnOK_Click()
    If TextBox1.Value = "" Then
        MsgBox "Mot de passe requis !": TextBox1.SetFocus: Exit Sub
    End If
    
    If Not VerifierMotDePasse(TextBox1.Value) Then
        MsgBox "MOT DE PASSE INCORRECT !"
        TextBox1.Value = "": TextBox1.SetFocus
        Exit Sub
    End If
    
    CreerLicence TextBox1.Value
    MsgBox "LICENCE ACTIV�E DE MANIERE PERMANENTE !"
    Unload Me
End Sub

Private Sub btnQuit_Click()
    Application.Quit
End Sub

Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    Cancel = True: Application.Quit
End Sub

