VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmNagScreen 
   Caption         =   "UserForm1"
   ClientHeight    =   3015
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   4560
   OleObjectBlob   =   "frmNagScreen.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmNagScreen"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub UserForm_Initialize()
    Me.ShowModal = False  ' Non-bloquant
    Me.Top = 100: Me.Left = 100
    
    Dim versionServeur As String: versionServeur = LireVersionDistanteOnline()
    Label1.Caption = "?? MISE � JOUR DISPONIBLE"
    Label1.ForeColor = RGB(200, 50, 50)
    Label1.Font.Size = 12: Label1.Font.Bold = True
    
    Label2.Caption = "Version Serveur : " & versionServeur
    Label3.Caption = "Votre version    : " & ObtenirVersionLocale()
    Label3.ForeColor = RGB(100, 100, 100)
    
    ' Timer refresh toutes les 30min
    Application.OnTime Now + TimeValue("00:30:00"), "RefreshNagScreen"
End Sub

Private Sub btnMAJ_Click()
    Unload Me
    ReimporterDepuisMappingSECURE
End Sub

Private Sub btnPlusTard_Click()
    CompteurRefus  ' Incr�mente compteur
    Me.Hide
End Sub
