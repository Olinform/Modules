Attribute VB_Name = "recupChemin"
Function recupCheminnNomEntreprise()

    Dim wb As Workbook, ws As Worksheet
    Set wb = ThisWorkbook
    Set ws = wb.Sheets(1)
    
    p = Split(wb.Path, ws.Range("NOMENTREPRISE"))(0)
    
    For i = 1 To Len(p)
        If Right(p, 1) <> "\" Then p = Left(p, Len(p) - 1) Else Exit For
        Debug.Print "p : " & p
    Next i
    dossierAvantEXCELS = Dir(p & "\*" & ws.Range("NOMENTREPRISE"), vbDirectory) & "\"

    If Right(p, 1) = "\" Then
        recupCheminnNomEntreprise = p & dossierAvantEXCELS
    Else: recupCheminnNomEntreprise = p & "\" & dossierAvantEXCELS
    End If
    
End Function

