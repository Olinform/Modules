Attribute VB_Name = "EnvoiMailVirementRecu"
Option Explicit

Public TEMP_PATH As String
Public MAILS_FILE As String
Public MDP_FILE As String

Public Function TraiterChangementPaiementPar(targetRow As Long, colPaiementPar As Variant, colPaiementRecule As Variant, ws As Worksheet, tarif As Double) As Boolean
    Dim fso As Object, ts As Object, ligne As String, emails As String
    Dim dansBloc As Boolean
    colPaiementRecule = Range(colPaiementRecule & 1).Column
    colPaiementPar = Range(colPaiementPar & 1).Column
    
    On Error GoTo ErrHandler
    
    MAILS_FILE = Environ("USERPROFILE") & "\Documents\(00) - TRAVAIL\00 - BATIMENT\01-OB PLOMBERIE\00 - FACTURES-DEVIS\2026\0 - AGENCES IMMO\mailsimmo.txt"
    
    Dim cellA As String, cellB As String, monEmail As String, emailsDest As String, mdpApp As String
    
    cellA = CStr(ws.Cells(targetRow, 1).Value)
    cellB = CStr(ws.Cells(targetRow, 2).Value)  ' ? Code agence pour recherche
    
    If Left(cellA, 4) <> "F_20" Then Exit Function
    If Trim(CStr(ws.Cells(targetRow, colPaiementRecule).Value)) = "" Then Exit Function
    
    If Not DemanderDoubleValidation(cellA, cellB, tarif) Then Exit Function
    
    TEMP_PATH = Environ("TEMP") & "\Security\"
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FileExists(MAILS_FILE) Then
        MsgBox "Fichier " & MAILS_FILE & " introuvable !", vbCritical
        Exit Function
    End If
    
    Set ts = fso.OpenTextFile(MAILS_FILE, 1)
    monEmail = ""
    dansBloc = False
    
    Do While Not ts.AtEndOfStream
        ligne = Trim(ts.ReadLine)
        
        ' Ligne vide = fin de bloc
        If monEmail <> "" Then
            Exit Do
        ElseIf ligne = "" Then
            dansBloc = False
        ' D�but de nouveau bloc si correspondance
        ElseIf ligne = "MOI" Then
            dansBloc = True
        ' Dans un bloc ? extraire emails
        ElseIf dansBloc Then
            ' Extraire email si contient @
            If InStr(ligne, "@") > 0 Then
                monEmail = ligne
            End If
        End If
    Loop
    ts.Close
    
    emailsDest = RechercherDestinataires(cellB)
    If emailsDest = "" Then Exit Function
    
    mdpApp = SaisirMDPApplication()
    If mdpApp = "" Then Exit Function
    
    EnvoyerMailGmail monEmail, emailsDest, cellA, mdpApp
    TraiterChangementPaiementPar = True
    Exit Function
    
ErrHandler:
    TraiterChangementPaiementPar = False
End Function

Private Function RechercherDestinataires(agenceCode As String) As String
    On Error GoTo ErrHandler
    Dim fso As Object, ts As Object, ligne As String, emails As String
    Dim dansBloc As Boolean
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FileExists(MAILS_FILE) Then
        MsgBox "? Fichier " & MAILS_FILE & " introuvable !", vbCritical
        Exit Function
    End If
    
    Set ts = fso.OpenTextFile(MAILS_FILE, 1)
    emails = ""
    dansBloc = False
    
    Do While Not ts.AtEndOfStream
        ligne = Trim(ts.ReadLine)
        
        ' Ligne vide = fin de bloc
        If ligne = "" And emails <> "" Then
            Exit Do
        ElseIf ligne = "" Then
            dansBloc = False
        ' D�but de nouveau bloc si correspondance
        ElseIf Not dansBloc And InStr(1, UCase(agenceCode), UCase(ligne), vbTextCompare) > 0 Then
            dansBloc = True
        ' Dans un bloc ? extraire emails
        ElseIf dansBloc Then
            ' Extraire email si contient @
            If InStr(ligne, "@") > 0 Then
                Dim email As String: email = ligne
                If email <> "" Then
                    If emails <> "" Then emails = emails & ";"
                    emails = emails & email
                End If
            End If
        End If
    Loop
    ts.Close
    
    If emails <> "" Then
        RechercherDestinataires = emails
        Debug.Print "Destinataires pour '" & agenceCode & "': " & emails
    Else
        MsgBox "Aucun destinataire trouv� pour '" & agenceCode & "' dans " & MAILS_FILE, vbExclamation
    End If
    Exit Function
    
ErrHandler:
    MsgBox "Erreur lecture " & MAILS_FILE & ": " & Err.Description, vbCritical
    RechercherDestinataires = ""
End Function

Private Function DemanderDoubleValidation(cellA As String, cellB As String, tarif As Double) As Boolean
    DemanderDoubleValidation = True
    Dim rep As Integer, Deuxrep As Integer
    rep = MsgBox("Facture " & cellA & " de " & tarif & "�," & vbCrLf & "pour " & cellB & vbCrLf & vbCrLf & _
    "Envoyer confirmation?", vbYesNo)
        If rep = vbNo Then
            DemanderDoubleValidation = False
            Exit Function
        Else
            Deuxrep = MsgBox("CONFIRMATION FINALE ?", vbYesNo + vbCritical)
            If Deuxrep = vbNo Then
                DemanderDoubleValidation = False
                Exit Function
            End If
        End If
End Function

Private Function SaisirMDPApplication() As String
    Dim mdp As String
    Dim lienAppPassword As String
    Dim besoinMDPGoogle As String
    
    lienAppPassword = "https://myaccount.google.com/u/1/apppasswords?rapt=AEjHL4OVyurkXGv--8-Ux7ko7pORvAiu2szGjH9VYHo_07xn3KB8d7aFRto6_95i-WT_d78KMov22gQ1QSqAge5WoqTUGiUbZ8u7TRMsQx_e0NSdD6waLA4"
    
    ' OUVERTURE DIRECTE DANS BRAVE
    
'    besoinMDPGoogle = MsgBox("Besoin du mot de passe Google Application ?" & vbCrLf & vbCrLf, vbYesNo)
'
'    If besoinMDPGoogle = vbYes Then
'        Shell "cmd /c start " & lienAppPassword
'    End If
    
    Do
'        mdp = InputBox("App Password g�n�r� ouvert dans Brave !" & vbCrLf & vbCrLf & _
'                       "1. Connectez-vous Gmail" & vbCrLf & _
'                       "2. S�curit� ? Mots de passe applications" & vbCrLf & _
'                       "3. G�N�RER ? COPIER 16 caract�res :" & vbCrLf & vbCrLf & _
'                       "Collez maintenant les 16 caract�res :", "App Password Gmail")
        mdp = Trim(Replace(Replace("flhk dfpq pnta kgre", " ", ""), vbTab, ""))

        ' SUPPRESSION ESPACES + TABS
        mdp = Trim(Replace(Replace(mdp, " ", ""), vbTab, ""))
        
        If Len(mdp) = 16 Then
            SaisirMDPApplication = mdp
            Debug.Print "App Password OK (" & Len(mdp) & " chars): " & Left(mdp, 4) & "..."
            Exit Function
        ElseIf mdp = "" Then
            Exit Function
        Else
            MsgBox "APP PASSWORD doit faire EXACTEMENT 16 caract�res !" & vbCrLf & _
                   "Votre saisie: " & Len(mdp) & " caract�res", vbCritical
        End If
    Loop
End Function

Private Sub EnvoyerMailGmail(monEmail As String, destinataires As String, factureRef As String, mdpApp As String)
    On Error GoTo ErrHandler
    Dim smtp As Object, config As Object, sujet As String, corps As String, payeur As String
    Debug.Print Range("B" & ActiveCell.Row).Comment.text
    payeur = Split(Range("B" & ActiveCell.Row).Comment.text, Chr(10))(1)
    
    sujet = "(MESS. AUTO) Vir. " & Range(Chr(64 + Range("TOTALTTC").Column) & ActiveCell.Row) & ChrW(8364) & " - " & payeur & " - " & factureRef & " re�u."
    corps = "Bonjour," & vbCrLf & vbCrLf & _
            "J'ai bien re�u le virement de " & Range(Chr(64 + Range("TOTALTTC").Column) & ActiveCell.Row) _
            & ChrW(8364) & " pour la facture " & factureRef & " pour " & payeur & ", le " & Range(Chr(64 + Range("paiementrecule").Column) & ActiveCell.Row) & _
            ", merci." & vbCrLf & vbCrLf & _
            "-- " & vbCrLf & _
            "Olivier BRIARD - OB PLOMBERIE" & vbCrLf & _
            "06 17 45 56 27" & vbCrLf _
            & Chr(40) & "ne pas r�pondre, message envoy� automatiquement" & Chr(41)
    
    Set smtp = CreateObject("CDO.Message"): Set config = smtp.Configuration
    With config.Fields
        .item("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
        .item("http://schemas.microsoft.com/cdo/configuration/smtpserver") = "smtp.gmail.com"
        .item("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 465
        .item("http://schemas.microsoft.com/cdo/configuration/smtpusessl") = True
        .item("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
        .item("http://schemas.microsoft.com/cdo/configuration/sendusername") = monEmail
        .item("http://schemas.microsoft.com/cdo/configuration/sendpassword") = mdpApp
        .item("http://schemas.microsoft.com/cdo/configuration/smtpconnectiontimeout") = 60
        .item("http://schemas.microsoft.com/cdo/configuration/contenttransferencoding") = "quoted-printable"
        .Update
    End With
    
    destinataires = destinataires & ";ob.plomberie@gmail.com"
'    destinataires = "ob.plomberie@gmail.com"
    
    smtp.BodyPart.Charset = "utf-8"

    smtp.From = monEmail
    smtp.To = destinataires
    smtp.Subject = sujet
    smtp.TextBody = corps
    
    smtp.Send
    
    destinataires = Replace(destinataires, ";", vbCrLf)
    Debug.Print "Mail envoy�: " & factureRef & " ? " & destinataires
    MsgBox "Mail envoy� avec succ�s � : " & vbCrLf & vbCrLf & destinataires
    Exit Sub
    
ErrHandler:
    MsgBox "Erreur envoi mail:" & vbCrLf & Err.Description & vbCrLf & _
           "Code: " & Err.Number & vbCrLf & vbCrLf & _
           "V�rifiez:" & vbCrLf & _
           "� App Password Gmail (16 chars)" & vbCrLf & _
           "� Connexion internet", vbCritical
End Sub


'Sub test()
'Dim sujet
'sujet = "(MESS. AUTO) Vir. " & _
'        Range(Chr(64 + Range("TOTALTTC").Column) & activecell.Row) & _
'        " � - " & " re�u."
'Debug.Print sujet
'End Sub

