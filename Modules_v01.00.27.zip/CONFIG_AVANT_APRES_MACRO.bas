Attribute VB_Name = "CONFIG_AVANT_APRES_MACRO"
Sub configAVANTMacro()

    'on force les configuration
        Application.ScreenUpdating = False
        Application.DisplayStatusBar = False
        Application.Calculation = xlCalculationManual
        Application.EnableEvents = False
        ActiveSheet.DisplayPageBreaks = False
End Sub


Sub configAPRESMacro()
Attribute configAPRESMacro.VB_ProcData.VB_Invoke_Func = "q\n14"

'configuration restaur�e
    Application.ScreenUpdating = True
    Application.DisplayStatusBar = True
    Application.Calculation = xlAutomatic
    Application.EnableEvents = True
    ActiveSheet.DisplayPageBreaks = False
    
End Sub
