Attribute VB_Name = "MOINS_UN"
 Sub MOINS_UN()
    If ActiveSheet.Name = "Factures" Then
        lignderfact = Cells(Rows.Count, 1).End(xlUp).Row
la:
        If Range("A" & lignderfact - 1) <> "" And InStr(Range("A" & lignderfact - 1), "F_") <> 0 Then
            lignderfact = lignderfact - 1
            GoTo la
        ElseIf Range("A" & lignderfact - 2) <> "" Then
            lignderfact = lignderfact - 2
            GoTo la
        End If
        
        If Range("C" & lignderfact) = "" And Left(Range("A" & lignderfact), 4) = "F_20" Then
            Rows(lignderfact & ":" & lignderfact + 3).EntireRow.Delete
        End If
    ElseIf ActiveSheet.Name = "Devis" Then
        lignDerDevis = Cells(Rows.Count, 1).End(xlUp).Row
        If Range("C" & lignDerDevis) = "" And Left(Range("A" & lignDerDevis), 4) = "D_20" Then
            Rows(lignDerDevis & ":" & lignDerDevis + 2).EntireRow.Delete
        End If
    End If
    
End Sub
