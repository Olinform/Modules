Attribute VB_Name = "B_LICENCE"
Public Sub RenouvelerLicence()
    ' Force la r�activation m�me si la licence est d�j� valide
    Dim mdp As String
    Dim ancienID As String
    
    ancienID = GetMachineID()
    
    ' Supprime l'ancienne licence s'il y en a une
    Dim cheminLicence As String
    cheminLicence = ThisWorkbook.Path & "\\.licence.dat"
    If Dir(cheminLicence) <> "" Then
        Kill cheminLicence
    End If
    
    ' Demande le nouveau mot de passe
    mdp = InputBox("Renouvellement de licence requis." & vbCrLf & _
                  "Entrez le NOUVEAU mot de passe administrateur :", _
                  "Renouvellement de licence")
    
    If mdp = "" Then
        MsgBox "Op�ration annul�e. La licence n'a pas �t� renouvel�e.", vbExclamation
        Exit Sub
    End If
    
    ' Tente de cr�er la nouvelle licence
    CreerLicence mdp
    
    If LicenceValide() Then
        MsgBox "Licence renouvel�e avec succ�s pour la machine : " & ancienID, vbInformation
    Else
        MsgBox "�chec du renouvellement. Mot de passe incorrect ou erreur technique.", vbCritical
        ' On ne remet pas l'ancienne licence, le fichier sera bloqu� jusqu'� correction
    End If
End Sub
Public Function GetMachineID() As String
    On Error GoTo Erreur
    Dim wmi As Object, machines As Object, machine As Object
    Set wmi = GetObject("winmgmts:\\.\root\cimv2")
    Set machines = wmi.ExecQuery("Select ProcessorId FROM Win32_Processor")
    For Each machine In machines
        GetMachineID = machine.ProcessorId
        If Len(GetMachineID) > 10 Then Exit Function
    Next
    GetMachineID = Environ("COMPUTERNAME")
    Exit Function
Erreur:
    GetMachineID = Environ("COMPUTERNAME")
End Function


Public Function VerifierMotDePasse(mdp As String) As Boolean
    VerifierMotDePasse = (mdp = MOT_DE_PASSE)
End Function

Public Function GetIDLicenceStocke() As String
    On Error GoTo Erreur
    Dim f As Integer
    f = FreeFile
    Open ThisWorkbook.Path & "\.licence.dat" For Input As #f
    Line Input #f, GetIDLicenceStocke
    Close #f
    Exit Function
Erreur:
    GetIDLicenceStocke = ""
End Function

Public Function LicenceValide() As Boolean
    On Error GoTo Erreur
    LicenceValide = (Dir(ThisWorkbook.Path & "\.licence.dat") <> "") And _
                   (GetMachineID() = GetIDLicenceStocke())
    Exit Function
Erreur:
    LicenceValide = False
End Function

Public Sub CreerLicence(mdp As String)
    If VerifierMotDePasse(mdp) Then
        Dim f As Integer
        f = FreeFile
        Open ThisWorkbook.Path & "\.licence.dat" For Output As #f
        Print #f, GetMachineID()
        Close #f
    End If
End Sub

Sub MonIDMachine()
    MsgBox "VOTRE ID = " & GetMachineID()
End Sub


