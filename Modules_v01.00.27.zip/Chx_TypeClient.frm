VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} Chx_TypeClient 
   Caption         =   "Choisir un client : "
   ClientHeight    =   1680
   ClientLeft      =   405
   ClientTop       =   1650
   ClientWidth     =   3405
   OleObjectBlob   =   "Chx_TypeClient.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "Chx_TypeClient"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False



Private Sub userform_activate()
    ' Position HAUT-GAUCHE qui FONCTIONNE � 100%
    Me.Left = (Application.Width / 2) - (Me.Width / 2)
    Me.Top = (Application.Height / 2) - (Me.Height / 2)

End Sub

Private Sub UserForm_Initialize()
    Me.Caption = "TYPE DE CLIENT"
    
    With Me.ListBox1.Font
        .Name = "Arial"           ' Police (optionnel)
        .Size = 13               ' ? TAILLE 12 (augmente � 14, 16...)
    End With
    ' ? La ListBox est d�j� remplie par le code appelant
End Sub

Private Sub ListBox1_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    If Me.ListBox1.ListIndex >= 0 Then
        CaptionChoisieTYPEClient = Me.ListBox1.Value  ' ? variable globale
        Unload Me
    End If
End Sub
