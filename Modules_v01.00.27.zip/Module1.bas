Attribute VB_Name = "Module1"
Public Const MOT_DE_PASSE = "MonGestionnaireDeFactures2026!"

Private Declare PtrSafe Function URLDownloadToFile Lib "urlmon" _
    Alias "URLDownloadToFileA" (ByVal pCaller As Long, ByVal szURL As String, _
    ByVal szFileName As String, ByVal dwReserved As Long, ByVal lpfnCB As Long) As Long

Option Explicit

Private Const APP_NAME As String = "MonAddin"
Private Const SEC_MAJ As String = "MiseAJour"
Private Const KEY_REFUS_COUNT As String = "RefusCount"
Private Const KEY_FIRST_REFUS_DATE As String = "FirstRefusDate"
Private Const MAX_REFUS As Long = 3
Private Const MAX_JOURS As Long = 7

Public gVersionTempPath As String

Public Function GetTempObfusquePath() As String
    Dim fso As Object, tempFolder As String, tempName As String
    tempFolder = Environ("TEMP")
    Set fso = CreateObject("Scripting.FileSystemObject")
    tempName = fso.GetTempName()
    GetTempObfusquePath = tempFolder & "\" & tempName
End Function

Public Function DoitBloquerMacros() As Boolean
    Dim refusCount As Long: refusCount = CLng(GetSetting(APP_NAME, SEC_MAJ, KEY_REFUS_COUNT, "0"))
    Dim firstRefusDate As Date
    Dim s As String: s = GetSetting(APP_NAME, SEC_MAJ, KEY_FIRST_REFUS_DATE, "")
    
    If s <> "" Then firstRefusDate = CDate(s) Else firstRefusDate = 0
    
    If refusCount = 0 Then DoitBloquerMacros = False: Exit Function
    
    If refusCount >= MAX_REFUS Or (firstRefusDate > 0 And DateDiff("d", firstRefusDate, Date) >= MAX_JOURS) Then
        DoitBloquerMacros = True
    Else
        DoitBloquerMacros = False
    End If
End Function

Public Sub EnregistrerRefusMiseAJour()
    Dim refusCount As Long: refusCount = CLng(GetSetting(APP_NAME, SEC_MAJ, KEY_REFUS_COUNT, "0"))
    Dim firstRefusDate As Date: firstRefusDate = IIf(GetSetting(APP_NAME, SEC_MAJ, KEY_FIRST_REFUS_DATE, "") = "", Date, CDate(GetSetting(APP_NAME, SEC_MAJ, KEY_FIRST_REFUS_DATE, "")))
    
    refusCount = refusCount + 1
    SaveSetting APP_NAME, SEC_MAJ, KEY_REFUS_COUNT, CStr(refusCount)
    SaveSetting APP_NAME, SEC_MAJ, KEY_FIRST_REFUS_DATE, CStr(firstRefusDate)
End Sub

Public Sub ReinitialiserCompteurMiseAJour()
    SaveSetting APP_NAME, SEC_MAJ, KEY_REFUS_COUNT, "0"
    SaveSetting APP_NAME, SEC_MAJ, KEY_FIRST_REFUS_DATE, ""
End Sub

